const { spawn } = require('child_process');
const path = require('path');

const DIR = __dirname;
const BUNDLE = path.join(DIR, 'sub-store.bundle.js');
const DIST = path.join(DIR, 'frontend');

console.log('启动 Sub-Store...');
const env = {
  ...process.env,
  SUB_STORE_FRONTEND_PATH: DIST,
  SUB_STORE_DATA_BASE_PATH: './data',
  SUB_STORE_FRONTEND_BACKEND_PATH: '/io123',
  PORT: process.env.PORT || '3000',
};

const proc = spawn('node', [BUNDLE], { env, stdio: 'inherit' });
proc.on('exit', code => process.exit(code));