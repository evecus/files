//! One TCP connection on the HTTP/1.1 listener: TLS (or plain text),
//! request heads, static files, and the WebSocket it may upgrade to, or
//! the bytes the handler serves itself (`RawConn`).
//!
//! Everything runs on the listener's loop thread. A connection is freed only
//! from its socket's deferred close, so a handler callback may do anything —
//! close the WebSocket, stop the server — and the code that called it can
//! still look at the connection afterwards.

const std = @import("std");
const posix = std.posix;
const sys = @import("../sys.zig");
const tls_server = @import("../tls/server.zig");
const parser = @import("parser.zig");
const websocket = @import("websocket.zig");
const socket = @import("socket.zig");
const timers = @import("timers.zig");
const Server = @import("server.zig").Server;
const StreamHandlers = @import("server.zig").StreamHandlers;
const http = @import("../http/exchange.zig");
const Exchange = http.Exchange;

const log = std.log.scoped(.http1);

pub const Header = parser.Header;

/// Our Close sent, waiting for the peer's.
const close_timeout_ms = 5_000;
/// Waiting for the peer's FIN after ours.
const linger_ms = 5_000;
/// Stop reading pipelined requests past this much unread input.
const max_pipelined_input = 64 * 1024;
/// An emptied input buffer keeps up to this much capacity, so a stream of
/// large messages doesn't free and regrow it for each one. A quiet
/// connection gives it back at its next ping timer.
const keep_input_capacity = 256 * 1024;
const file_chunk = 16 * 1024;
/// Messages up to this size go out as one write (one TLS record).
const coalesce_limit = 16 * 1024;

const Phase = enum {
    /// Waiting for a request head (and, first, the TLS handshake).
    head,
    /// Sending a file.
    static_body,
    /// Upgraded.
    ws_open,
    /// Our Close is out; waiting for the peer's.
    ws_closing,
    /// The handler's, as bytes: see `RawConn`.
    raw,
    /// A request offered to the handler (`HttpExchange`), waiting on its
    /// answer; input after it waits too.
    exchange,
    /// A request offered at its head (`onHttpHead`): its body goes to the
    /// handler as it arrives; input after the body waits for the answer.
    stream,
    /// Flushing, lingering or aborting; nothing more is read or written.
    closing,
    /// A WebSocket handed over (`WsConn.handOver`), waiting for its socket
    /// to come off the loop.
    moving,
};

pub const SendError = error{
    /// The WebSocket is closing or gone.
    Closed,
    /// More than `max_send_buffer` bytes would be waiting for the socket.
    /// Nothing was queued.
    SendBufferFull,
};

/// An open WebSocket. Valid from `WsRequest.accept` until `onWsClose`
/// returns; use it only on the loop's thread.
pub const WsConn = struct {
    ws_id: u64 = 0,
    decoder: websocket.Decoder = .init(0),
    /// The handler has heard `onWsClose`, or was never given this handle.
    notified: bool = true,
    close_sent: bool = false,
    /// Bytes arrived since the last ping timer.
    rx_bytes: usize = 0,
    /// `sock.drained` at the last ping timer.
    drained_mark: u64 = 0,
    ping_outstanding: bool = false,

    fn conn(self: *WsConn) *Conn {
        return @alignCast(@fieldParentPtr("ws", self));
    }

    fn constConn(self: *const WsConn) *const Conn {
        return @alignCast(@fieldParentPtr("ws", self));
    }

    /// Unique within the server and never reused. Drawn from the same
    /// counter as `Session.id()` when the listener runs inside an
    /// `event_loop.Server`, so one map can key both.
    pub fn id(self: *const WsConn) u64 {
        return self.ws_id;
    }

    /// Sends one binary message. Safe from any callback on the loop,
    /// including ones for other connections; it goes to the socket at once.
    pub fn send(self: *WsConn, data: []const u8) SendError!void {
        return self.conn().sendMessage(.binary, data);
    }

    /// Sends one text message. `data` must be UTF-8; it isn't checked.
    pub fn sendText(self: *WsConn, data: []const u8) SendError!void {
        return self.conn().sendMessage(.text, data);
    }

    /// Move this WebSocket, with its TLS session, unread input and unsent
    /// output, to a `Server` on another loop: another thread's, on the same
    /// port. Only from `onWsMessage`, whose message is then the last this
    /// server delivers. Once no read or write of it is in flight here, the
    /// handler's `onWsHandover` gets it, on this thread, to pass to the new
    /// server's, where `Server.adopt` takes it in. Don't use this handle
    /// again: sends fail meanwhile, and no `onWsClose` comes here unless the
    /// server stops first.
    pub fn handOver(self: *WsConn) HandoverError!void {
        return self.conn().handOver();
    }

    /// Starts the closing handshake. `onWsClose` follows once the peer
    /// answers, or with 1006 when it doesn't within 5 s; never from inside
    /// this call. A code a peer may not receive (1005, 1006, 1015, or
    /// outside the defined ranges) is sent as 1000. `reason` is cut to fit
    /// a control frame.
    pub fn close(self: *WsConn, code: u16, reason: []const u8) void {
        self.conn().closeWebSocket(code, reason);
    }

    /// Hold this connection's output until `uncork`, which sends it in one
    /// go: for a host with several messages for it at once, such as one
    /// answering a batch of events. Sends still count against
    /// `max_send_buffer` meanwhile.
    ///
    /// What `onWsMessage` sends leaves without it, together with the
    /// answers to the other frames of the same read; an uncork there sends
    /// with them.
    pub fn cork(self: *WsConn) void {
        self.conn().sock.cork();
    }

    pub fn uncork(self: *WsConn) void {
        self.conn().sock.uncork();
    }

    /// Bytes queued for the socket and not yet taken by the kernel,
    /// counting TLS framing. What a producer compares against its own
    /// high-water mark before sending something it may drop. In
    /// `onWsMessage` it counts the read's answers held to leave together
    /// too, up to 64 KiB.
    pub fn bufferedAmount(self: *const WsConn) usize {
        return self.constConn().sock.buffered();
    }

    pub fn peerAddress(self: *const WsConn) *const posix.sockaddr.storage {
        return &self.constConn().peer;
    }

    /// The kernel's smoothed round trip for this connection's TCP socket,
    /// in nanoseconds, the unit of `Session.getStats().smoothed_rtt_ns`.
    /// Microsecond resolution on Linux (`TCP_INFO`), millisecond on macOS
    /// (`TCP_CONNECTION_INFO`). 0 until the kernel has a sample; null on
    /// other platforms or when the query fails. A syscall each call.
    pub fn rtt(self: *const WsConn) ?u64 {
        return socket.tcpRtt(self.constConn().sock.fd());
    }
};

pub const HandoverError = error{
    /// The handler has no `onWsHandover`.
    HandoverNotConfigured,
    /// Not called from `onWsMessage`.
    NotInMessage,
    /// The WebSocket is closing or gone.
    Closed,
};

/// A WebSocket on its way from one server to another: from the old one's
/// `onWsHandover` to the new one's `Server.adopt`. It must reach exactly one
/// `adopt`, or `discard`.
pub const WsHandover = struct {
    conn: *Conn,

    /// The WebSocket's id, which it keeps on the new server.
    pub fn id(self: WsHandover) u64 {
        return self.conn.ws.ws_id;
    }

    /// Free a WebSocket no server will adopt, with no Close frame: the peer
    /// sees its TCP connection end.
    pub fn discard(self: WsHandover) void {
        const c = self.conn;
        c.sock.closeFd();
        c.sock.freeBuffers();
        c.free();
    }
};

pub const AcceptOptions = struct {
    /// Sec-WebSocket-Protocol to answer with. Must be one the client offered.
    protocol: ?[]const u8 = null,
    /// Extra response headers (Set-Cookie, say).
    headers: []const Header = &.{},
};

pub const AcceptError = error{
    /// `accept` or `reject` was already called.
    AlreadyDecided,
    /// The connection failed meanwhile.
    Closed,
    /// `AcceptOptions.protocol` isn't in the client's Sec-WebSocket-Protocol.
    ProtocolNotOffered,
    /// A header in `AcceptOptions.headers` isn't a valid field.
    InvalidHeader,
    OutOfMemory,
};

/// A WebSocket upgrade request, valid only during `onWsUpgrade`. The
/// handler calls `accept` or `reject`; a request left undecided is
/// rejected with 403.
pub const WsRequest = struct {
    conn: *Conn,
    head: *const parser.RequestHead,
    key: []const u8,
    decision: enum { pending, accepted, rejected } = .pending,

    /// A request header, matched case-insensitively.
    pub fn header(self: *const WsRequest, name: []const u8) ?[]const u8 {
        return self.head.get(name);
    }

    pub fn headers(self: *const WsRequest) []const Header {
        return self.head.headers;
    }

    /// Whether the client listed `protocol` in Sec-WebSocket-Protocol.
    pub fn offersProtocol(self: *const WsRequest, protocol: []const u8) bool {
        return websocket.protocolOffered(self.head, protocol);
    }

    pub fn peerAddress(self: *const WsRequest) *const posix.sockaddr.storage {
        return &self.conn.peer;
    }

    /// Answers 101 and returns the WebSocket, which can send right away.
    pub fn accept(self: *WsRequest, opts: AcceptOptions) AcceptError!*WsConn {
        if (self.decision != .pending) return error.AlreadyDecided;
        const c = self.conn;
        if (!c.sock.isOpen()) return error.Closed;
        if (opts.protocol) |p| {
            if (!websocket.protocolOffered(self.head, p)) return error.ProtocolNotOffered;
        }
        for (opts.headers) |h| {
            if (!parser.isToken(h.name) or !parser.isFieldValue(h.value)) return error.InvalidHeader;
        }

        const gpa = c.server.alloc;
        var out: std.ArrayList(u8) = .empty;
        defer out.deinit(gpa);
        const accept_key = websocket.acceptKey(self.key);
        try out.print(gpa, "HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n" ++
            "Sec-WebSocket-Accept: {s}\r\n", .{&accept_key});
        if (opts.protocol) |p| try out.print(gpa, "Sec-WebSocket-Protocol: {s}\r\n", .{p});
        for (opts.headers) |h| try out.print(gpa, "{s}: {s}\r\n", .{ h.name, h.value });
        try out.appendSlice(gpa, "\r\n");

        self.decision = .accepted;
        c.output(out.items);
        c.startWebSocket();
        return &c.ws;
    }

    /// Answers with `status` and closes the connection; nothing is upgraded.
    pub fn reject(self: *WsRequest, status: u16) void {
        if (self.decision != .pending) return;
        self.decision = .rejected;
        self.conn.respond(status, parser.reason(status), .close, null);
    }
};

/// A GET or HEAD request that isn't an upgrade, valid only during the
/// handler's `onHttpRequest`. Unanswered, it goes to the handler's
/// `onRawOpen` when it has one, and to the static files otherwise.
pub const HttpRequest = struct {
    conn: *Conn,
    head: *const parser.RequestHead,
    answered: bool = false,

    /// A request header, matched case-insensitively.
    pub fn header(self: *const HttpRequest, name: []const u8) ?[]const u8 {
        return self.head.get(name);
    }

    /// Answers with `body` (left out for HEAD), all of it queued now.
    pub fn respond(self: *HttpRequest, status: u16, content_type: []const u8, body: []const u8) void {
        self.respondWith(status, content_type, "", body);
    }

    /// `respond`, with `headers` too: whole header lines, each ending in
    /// `\r\n` (`"Access-Control-Allow-Origin: *\r\n"`, say).
    pub fn respondWith(self: *HttpRequest, status: u16, content_type: []const u8, headers: []const u8, body: []const u8) void {
        if (self.answered) return;
        self.answered = true;
        const c = self.conn;
        var buf: [1024]u8 = undefined;
        var w: std.Io.Writer = .fixed(&buf);
        const head = blk: {
            w.print("HTTP/1.1 {d} {s}\r\nContent-Type: {s}\r\nContent-Length: {d}\r\n{s}", .{
                status, parser.reason(status), content_type, body.len, headers,
            }) catch break :blk null;
            c.writeCommonHeaders(&w, !c.keep_alive) catch break :blk null;
            w.writeAll("\r\n") catch break :blk null;
            break :blk w.buffered();
        } orelse return c.respond(500, "Internal server error", .close, null);
        c.output(head);
        if (!c.head_only) c.output(body);
        c.responseDone();
    }
};

/// Requests with bodies past this, or chunked ones, aren't offered as
/// exchanges: they go on as if the handler took none.
pub const max_exchange_body = 64 * 1024;

/// A request the handler answers when it's ready, `onHttpExchange`'s: its
/// head and body have all arrived when it's offered. The handler calls
/// `respond`, or `pass` to have it served as if never offered: by the raw
/// handler when there is one. Until then nothing more is read from the
/// connection. Valid until one of those, or until `onHttpExchangeGone`
/// says the connection closed first; use it only on the loop's thread.
pub const HttpExchange = struct {
    exchange_id: u64 = 0,
    pending: bool = false,
    /// Inside `onHttpExchange`: `head` and `body_bytes` are set.
    offering: bool = false,
    passed: bool = false,
    /// The request's bytes, head and body, at the start of the input.
    len: usize = 0,
    head: ?*const parser.RequestHead = null,
    body_bytes: []const u8 = &.{},

    fn conn(self: *HttpExchange) *Conn {
        return @alignCast(@fieldParentPtr("exchange", self));
    }

    /// From the counter `WsConn.id` draws from.
    pub fn id(self: *const HttpExchange) u64 {
        return self.exchange_id;
    }

    // The request, during `onHttpExchange` only.

    pub fn method(self: *const HttpExchange) []const u8 {
        return self.head.?.method;
    }

    pub fn target(self: *const HttpExchange) []const u8 {
        return self.head.?.target;
    }

    pub fn headers(self: *const HttpExchange) []const parser.Header {
        return self.head.?.headers;
    }

    pub fn body(self: *const HttpExchange) []const u8 {
        return self.body_bytes;
    }

    pub fn peerAddress(self: *HttpExchange) *const posix.sockaddr.storage {
        return &self.conn().peer;
    }

    /// Answers with `body` (left out for HEAD) after `extra_headers`: whole
    /// header lines, each ending in `\r\n`. Content-Length is added, and
    /// Connection as the request asked.
    pub fn respond(self: *HttpExchange, status: u16, extra_headers: []const u8, response_body: []const u8) void {
        if (!self.pending) return;
        self.pending = false;
        const c = self.conn();
        if (!self.offering) c.consumeInput(self.len);
        // Then what the peer pipelined behind it (`responseDone`).
        c.answer(status, extra_headers, response_body);
    }

    /// Serves the request as if it had never been offered.
    pub fn pass(self: *HttpExchange) void {
        if (!self.pending) return;
        self.pending = false;
        self.passed = true;
        const c = self.conn();
        c.phase = .head;
        if (self.offering) return;
        // Parsed again from the input, which still holds it whole.
        c.skip_exchange = true;
        c.process();
    }
};

pub const RawError = error{
    /// The connection is closing or gone.
    Closed,
};

/// A connection the handler serves itself, as bytes: a request the server
/// doesn't answer, from its request line on, and everything after it on
/// the connection, through TLS when the listener has it. For a host with
/// an HTTP/1.1 implementation of its own. Valid from `onRawOpen` until
/// `onRawClose` returns; use it only on the loop's thread.
pub const RawConn = struct {
    raw_id: u64 = 0,
    /// The handler has heard `onRawClose`, or was never given this handle.
    notified: bool = true,
    /// By `pauseReading`, apart from the output backpressure every phase has.
    paused: bool = false,
    /// A write left `socket.low_water` or more queued: `onRawDrain` is owed.
    full: bool = false,
    /// The peer sent its last byte, and the handler has heard.
    ended: bool = false,

    fn conn(self: *RawConn) *Conn {
        return @alignCast(@fieldParentPtr("raw", self));
    }

    fn constConn(self: *const RawConn) *const Conn {
        return @alignCast(@fieldParentPtr("raw", self));
    }

    /// From the counter `WsConn.id` draws from.
    pub fn id(self: *const RawConn) u64 {
        return self.raw_id;
    }

    /// Queues all of `data`, refusing none. Once a write leaves
    /// `socket.low_water` or more queued, `onRawDrain` follows when it falls
    /// below again: a producer past its own mark waits for that.
    pub fn write(self: *RawConn, data: []const u8) RawError!void {
        const c = self.conn();
        if (self.notified or c.phase != .raw or !c.sock.isOpen()) return error.Closed;
        c.output(data);
        // A failed write aborts; `onRawClose` follows from the deferred close.
        if (!c.sock.isOpen()) return error.Closed;
        if (c.sock.buffered() >= socket.low_water) self.full = true;
    }

    /// Sends what is queued, then ends the connection. `onRawClose`
    /// follows once the socket is closed; never from inside this call.
    pub fn close(self: *RawConn) void {
        const c = self.conn();
        if (self.notified or c.phase != .raw) return;
        c.enterClosing(.graceful);
    }

    /// Ends the connection now, dropping what is queued: a host's
    /// `destroy()`. After `close()` it does nothing, so a close's output
    /// still goes out. `onRawClose` follows, never from inside this call.
    pub fn abort(self: *RawConn) void {
        const c = self.conn();
        if (self.notified or c.phase != .raw) return;
        c.enterClosing(.abort);
    }

    /// No more `onRawData` until `resumeReading`; the peer stalls once the
    /// kernel's buffers fill.
    pub fn pauseReading(self: *RawConn) void {
        if (self.paused) return;
        self.paused = true;
        self.conn().sock.pauseRead();
    }

    /// Input already buffered arrives from a deferred callback, never from
    /// inside this call.
    pub fn resumeReading(self: *RawConn) void {
        if (!self.paused) return;
        self.paused = false;
        const c = self.conn();
        // Output over high water: onSocketWritable resumes once it drains.
        if (c.phase != .raw or c.sock.buffered() > socket.high_water) return;
        c.sock.read_paused = false;
        c.server.timers.defer_(&c.resume_cb);
    }

    /// Hold this connection's output until `uncork`, which sends it in one
    /// go. A drain a corked write owes still comes, after the uncork.
    pub fn cork(self: *RawConn) void {
        self.conn().sock.cork();
    }

    pub fn uncork(self: *RawConn) void {
        self.conn().sock.uncork();
    }

    /// Bytes queued for the socket and not yet taken by the kernel,
    /// counting TLS framing.
    pub fn bufferedAmount(self: *const RawConn) usize {
        return self.constConn().sock.buffered();
    }

    /// Whether an `onRawDrain` is on its way: a write left low water or
    /// more queued, and the output hasn't fallen below it since.
    pub fn owesDrain(self: *const RawConn) bool {
        return self.full;
    }

    pub fn peerAddress(self: *const RawConn) *const posix.sockaddr.storage {
        return &self.constConn().peer;
    }
};

/// The request `onHttpHead` was offered: its body as it comes in, and how
/// the answer goes out.
const Stream = struct {
    ex: Exchange = .idle,
    body: parser.BodyDecoder = .{ .chunked = false, .done = true },
    chunked: bool = false,
    /// A write left `socket.low_water` or more queued: `onHttpWritable` is owed.
    full: bool = false,

    fn live(s: *const Stream) bool {
        return s.ex.answer != .done;
    }
};

pub const Conn = struct {
    server: *Server,
    sock: socket.Socket(Conn),
    /// Its own allocation: a plain connection shouldn't carry TLS's state.
    tls: ?*tls_server.Conn,
    peer: posix.sockaddr.storage,

    /// Plaintext received and not yet consumed, from `in_pos` on. Only a
    /// plain connection's partial request or frame lands here: input is
    /// parsed where it arrives (the socket's read buffer, TLS's plaintext
    /// buffer), and only what is left over is copied.
    in: std.ArrayList(u8) = .empty,
    in_pos: usize = 0,
    phase: Phase = .head,
    deadline: timers.Deadline = .{ .callback = onDeadline },
    /// The request body on its way in, against `Config.min_body_rate`.
    body_window: ?http.BodyWindow = null,
    processing: bool = false,
    /// Inside the handler's `onWsMessage`.
    in_message: bool = false,
    /// Adopted: reads what the old server left unread, then reads on.
    resume_cb: timers.Deferred = .{ .callback = onResume },

    // The request being answered.
    keep_alive: bool = true,
    http10: bool = false,
    head_only: bool = false,
    file: ?sys.File = null,
    file_remaining: u64 = 0,

    ws: WsConn = .{},
    raw: RawConn = .{},
    exchange: HttpExchange = .{},
    /// The request at the start of the input was passed: serve it without
    /// offering it again.
    skip_exchange: bool = false,
    stream: Stream = .{},

    // The server's list.
    prev: ?*Conn = null,
    next: ?*Conn = null,

    pub fn create(server: *Server, fd: posix.socket_t) !*Conn {
        const gpa = server.alloc;
        const tls = if (server.tlsConfig()) |tc| blk: {
            const t = try gpa.create(tls_server.Conn);
            t.* = tls_server.Conn.init(gpa, tc);
            break :blk t;
        } else null;
        errdefer if (tls) |t| gpa.destroy(t);
        const self = try gpa.create(Conn);
        errdefer gpa.destroy(self);
        self.* = .{
            .server = server,
            .sock = undefined,
            .tls = tls,
            .peer = undefined,
        };
        var len: posix.socklen_t = @sizeOf(posix.sockaddr.storage);
        sys.getpeername(fd, @ptrCast(&self.peer), &len) catch {
            self.peer = std.mem.zeroes(posix.sockaddr.storage);
        };
        try self.sock.init(self, server.loop, &server.timers, gpa, server.xevTcp(fd));
        server.timers.set(&self.deadline, server.config.handshake_timeout_ms);
        self.sock.startReading();
        return self;
    }

    fn destroy(self: *Conn) void {
        self.server.timers.clear(&self.deadline);
        self.free();
    }

    fn free(self: *Conn) void {
        const gpa = self.sock.alloc;
        self.closeFile();
        self.ws.decoder.deinit(gpa);
        if (self.tls) |t| {
            t.deinit();
            gpa.destroy(t);
        }
        self.in.deinit(gpa);
        gpa.destroy(self);
    }

    /// Frees the connection without the loop: the server is being torn
    /// down and the loop will not run again.
    pub fn teardown(self: *Conn) void {
        self.notifyClose(websocket.CloseCode.going_away, "");
        self.sock.closeFd();
        self.sock.freeBuffers();
        self.destroy();
    }

    // ─── Socket events ───────────────────────────────────────────────

    pub fn onSocketData(self: *Conn, data: []u8) void {
        if (self.phase == .ws_open or self.phase == .ws_closing) self.ws.rx_bytes +|= data.len;
        if (self.tls) |t| {
            t.feed(data) catch |err| {
                log.debug("tls: {s}", .{@errorName(err)});
                // The alert is queued; send it before closing.
                self.flushTls();
                return self.finish(websocket.CloseCode.abnormal, .graceful);
            };
            self.flushTls();
            self.process();
            if (t.peerClosed() and self.phase != .moving) self.onSocketEof();
            return;
        }
        if (self.in.items.len > self.in_pos) {
            self.in.appendSlice(self.server.alloc, data) catch return self.finish(websocket.CloseCode.abnormal, .abort);
            return self.process();
        }
        // Nothing buffered: parse straight from the read buffer and keep
        // only what is left over, typically nothing.
        self.in.clearRetainingCapacity();
        self.in_pos = 0;
        const used = self.processBuf(data) orelse 0;
        if (used == data.len or !self.sock.isOpen()) return;
        self.in.appendSlice(self.server.alloc, data[used..]) catch return self.finish(websocket.CloseCode.abnormal, .abort);
        self.afterInput();
    }

    pub fn onSocketEof(self: *Conn) void {
        switch (self.phase) {
            // Let what is queued go out; the socket ends itself.
            .closing => {},
            // A client that half-closed after its request still gets the answer.
            .head => self.enterClosing(.graceful),
            // A WebSocket that ends without a Close frame is abnormal (1006).
            .static_body, .ws_open, .ws_closing => self.finish(websocket.CloseCode.abnormal, .abort),
            .raw => self.rawEnd(),
            // Half-closed after its request: it still gets the answer, then
            // the connection ends.
            .exchange => self.keep_alive = false,
            .stream => if (self.stream.body.done) {
                self.keep_alive = false;
            } else self.finish(websocket.CloseCode.abnormal, .abort),
            // A failed write: the new server reads the end.
            .moving => {},
        }
    }

    pub fn onSocketWritable(self: *Conn) void {
        switch (self.phase) {
            .static_body => self.pumpFile(),
            // Output drained after afterInput paused for it: answer what was
            // left buffered, then read again. In that order, so a message
            // that hands the WebSocket over finds no read armed.
            .head, .ws_open, .ws_closing => self.readAgain(),
            .raw => {
                if (self.raw.full) {
                    self.raw.full = false;
                    const h = self.server.handlers;
                    if (h.raw.?.drain) |drain| drain(h.ctx, &self.raw);
                }
                if (self.phase == .raw and !self.raw.paused) self.readAgain();
            },
            .stream => {
                if (self.stream.full) {
                    self.stream.full = false;
                    const h = self.server.handlers;
                    if (h.stream.?.writable) |writable| writable(h.ctx, &self.stream.ex);
                }
                if (self.phase == .stream) {
                    self.armStream();
                    self.readAgain();
                }
            },
            // Its answer resumes reading, once it's written.
            .exchange, .closing, .moving => {},
        }
    }

    /// Reading stopped while output drained: answer what was left buffered,
    /// then read on.
    fn readAgain(self: *Conn) void {
        if (!self.sock.read_paused) return;
        self.sock.read_paused = false;
        if (self.unreadLen() > 0) self.process();
        self.sock.startReading();
    }

    /// A WebSocket handed over has its socket off the loop: it leaves for
    /// the handler's `onWsHandover`.
    pub fn onSocketParked(self: *Conn) void {
        if (self.phase != .moving or self.server.stopping) return;
        self.server.removeConn(self);
        self.server.ws_count -= 1;
        const h = self.server.handlers;
        h.handover.?(h.ctx, .{ .conn = self });
    }

    fn onResume(d: *timers.Deferred) void {
        const self: *Conn = @alignCast(@fieldParentPtr("resume_cb", d));
        if (!self.sock.isOpen()) return;
        if (self.unreadLen() > 0) self.process();
        if (self.tls) |t| if (t.peerClosed()) return self.onSocketEof();
        self.sock.startReading();
    }

    pub fn onSocketClosed(self: *Conn) void {
        // Backstop for failures found while writing: the handler hears of
        // them here, from a deferred callback, never inside `send`.
        self.notifyClose(websocket.CloseCode.abnormal, "");
        self.server.removeConn(self);
        self.destroy();
    }

    fn onDeadline(d: *timers.Deadline) void {
        const self: *Conn = @alignCast(@fieldParentPtr("deadline", d));
        switch (self.phase) {
            .ws_open => self.onPingTimer(),
            // No Close answered ours; the connection ends abnormally.
            .ws_closing => self.finish(websocket.CloseCode.abnormal, .abort),
            // Cleared by handOver.
            .moving => {},
            // Never set: the handler keeps its own time.
            .raw, .exchange => {},
            // A body that kept up gets another window.
            .head, .stream => if (self.bodyKeptUp()) self.armBodyWindow() else self.finish(websocket.CloseCode.abnormal, .abort),
            // Handshake, idle keep-alive, a stalled answer, or linger.
            .static_body, .closing => self.finish(websocket.CloseCode.abnormal, .abort),
        }
    }

    // ─── Output ──────────────────────────────────────────────────────

    /// Sends plaintext, through TLS when the listener has it.
    fn output(self: *Conn, bytes: []const u8) void {
        if (bytes.len == 0) return;
        if (self.tls) |t| {
            t.write(bytes) catch return self.sock.abort();
            self.flushTls();
        } else {
            self.sock.write(bytes);
        }
    }

    fn flushTls(self: *Conn) void {
        const t = self.tls orelse return;
        const pending = t.pendingOutput();
        if (pending.len == 0) return;
        self.sock.write(pending);
        t.consumeOutput(pending.len);
    }

    const How = enum { graceful, abort };

    /// Ends the connection: the handler hears `onWsClose(code)` first if a
    /// WebSocket is open, then the socket closes, flushing what is queued
    /// when `graceful`.
    fn finish(self: *Conn, code: u16, how: How) void {
        self.notifyClose(code, "");
        self.enterClosing(how);
    }

    fn enterClosing(self: *Conn, how: How) void {
        self.phase = .closing;
        self.closeFile();
        switch (how) {
            .graceful => {
                if (self.tls) |t| {
                    t.close();
                    self.flushTls();
                }
                self.sock.closeAfterFlush();
                self.server.timers.set(&self.deadline, linger_ms);
            },
            .abort => {
                self.server.timers.clear(&self.deadline);
                self.sock.abort();
            },
        }
    }

    fn notifyClose(self: *Conn, code: u16, reason: []const u8) void {
        if (self.stream.live()) {
            self.stream.ex.answer = .done;
            const h = self.server.handlers;
            h.stream.?.gone(h.ctx, &self.stream.ex);
        }
        if (self.exchange.pending) {
            self.exchange.pending = false;
            const h = self.server.handlers;
            h.exchange.?.gone(h.ctx, &self.exchange);
        }
        if (!self.raw.notified) {
            self.raw.notified = true;
            const h = self.server.handlers;
            return h.raw.?.close(h.ctx, &self.raw);
        }
        if (self.ws.notified) return;
        self.ws.notified = true;
        self.server.ws_count -= 1;
        self.server.handlers.close(self.server.handlers.ctx, &self.ws, code, reason);
    }

    // ─── Input ───────────────────────────────────────────────────────

    /// Handles what is buffered: TLS's plaintext, or `in`.
    fn process(self: *Conn) void {
        if (self.tls) |t| {
            // Only `feed` moves TLS's plaintext, and nothing in here feeds.
            const used = self.processBuf(t.unread()) orelse return;
            t.consume(used);
        } else {
            const used = self.processBuf(self.in.items[self.in_pos..]) orelse return;
            self.in_pos += used;
            self.compactInput();
        }
        self.afterInput();
    }

    /// Runs requests and frames from `buf` until one is incomplete or the
    /// phase stops taking input; returns how much of `buf` it used, or null
    /// when re-entered: a response that finishes inside the loop leads back
    /// here, and the loop picks the new phase up itself.
    fn processBuf(self: *Conn, buf: []u8) ?usize {
        if (self.processing) return null;
        self.processing = true;
        defer self.processing = false;
        // A WebSocket's answers to frames read together leave in one send.
        self.sock.batch(self.phase == .ws_open);
        defer self.sock.batch(false);
        var pos: usize = 0;
        // Past high_water the rest waits: a peer that sends and never reads
        // would otherwise have every pipelined request answered into memory.
        while (self.sock.isOpen() and self.sock.buffered() <= socket.high_water) {
            const used = switch (self.phase) {
                .head => self.processHead(buf[pos..]),
                .ws_open, .ws_closing => self.processFrame(buf[pos..]),
                .raw => self.processRaw(buf[pos..]),
                .stream => self.processStreamBody(buf[pos..]),
                .static_body, .exchange, .closing, .moving => null,
            } orelse break;
            pos += used;
        }
        return pos;
    }

    fn unreadLen(self: *Conn) usize {
        if (self.tls) |t| return t.unread().len;
        return self.in.items.len - self.in_pos;
    }

    fn afterInput(self: *Conn) void {
        if ((self.phase == .static_body or self.phase == .stream) and self.unreadLen() > max_pipelined_input) self.sock.pauseRead();
        // Resumed by onSocketWritable once the output drains.
        if (self.sock.buffered() > socket.high_water) self.sock.pauseRead();
    }

    fn compactInput(self: *Conn) void {
        if (self.in_pos == 0) return;
        const rest = self.in.items.len - self.in_pos;
        @memmove(self.in.items[0..rest], self.in.items[self.in_pos..]);
        self.in.items.len = rest;
        self.in_pos = 0;
        if (rest == 0 and self.in.capacity > keep_input_capacity) self.in.clearAndFree(self.server.alloc);
    }

    /// Handles the request head at the start of `buf`, if all of it has
    /// arrived; returns its length.
    fn processHead(self: *Conn, buf: []u8) ?usize {
        var hb: [100]Header = undefined;
        const parsed = parser.parseRequest(buf, &hb, .{}) catch |err| {
            const status: u16 = switch (err) {
                error.HeadTooLarge => 431,
                error.TooManyHeaders => 431,
                error.VersionNotSupported => 505,
                error.NotImplemented => 501,
                error.BadRequest => 400,
            };
            self.respond(status, parser.reason(status), .close, null);
            return null;
        } orelse return null;
        self.server.timers.clear(&self.deadline);
        const head = &parsed.head;
        self.keep_alive = head.keep_alive and !self.server.draining;
        self.http10 = head.version == .http10;
        self.head_only = std.mem.eql(u8, head.method, "HEAD");

        const h = self.server.handlers;
        if (websocket.isUpgrade(head) and h.upgrade != null) {
            self.handleUpgrade(head);
            return parsed.len;
        }
        const is_get = std.mem.eql(u8, head.method, "GET") or self.head_only;
        if (is_get and !head.hasBody()) if (h.request) |onRequest| {
            var req: HttpRequest = .{ .conn = self, .head = head };
            onRequest(h.ctx, &req, head.target);
            if (req.answered) return parsed.len;
        };
        if (h.stream) |st| if (self.startStream(st, head) == .taken) return parsed.len;
        if (h.exchange) |ex| if (!self.skip_exchange and offerable(head)) {
            const total = parsed.len + @as(usize, @intCast(head.content_length orelse 0));
            if (buf.len < total) {
                // The head is parsed again once the body is in.
                if (self.body_window == null) self.body_window = .start(timers.nowMs(), self.server.config.stall_timeout_ms);
                self.body_window.?.got = buf.len - parsed.len;
                self.armBodyWindow();
                return null;
            }
            self.body_window = null;
            switch (self.offer(ex, head, total, buf[parsed.len..total])) {
                // Input stays put, the request at its start, for the answer.
                .waiting => return 0,
                .responded => return total,
                .passed => {},
            }
        };
        self.skip_exchange = false;
        if (h.raw != null) return self.startRaw();
        if (!is_get) {
            self.respond(405, "Method not allowed", .close, "Allow: GET, HEAD\r\n");
        } else if (head.hasBody()) {
            self.respond(400, "Unexpected request body", .close, null);
        } else {
            self.serveStatic(head.target);
        }
        return parsed.len;
    }

    fn offerable(head: *const parser.RequestHead) bool {
        return !head.chunked and !head.expect_continue and (head.content_length orelse 0) <= max_exchange_body;
    }

    fn offer(self: *Conn, ex: anytype, head: *const parser.RequestHead, total: usize, body: []const u8) enum { waiting, responded, passed } {
        self.phase = .exchange;
        self.exchange = .{ .exchange_id = self.server.nextId(), .pending = true, .offering = true, .len = total, .head = head, .body_bytes = body };
        const h = self.server.handlers;
        ex.offer(h.ctx, &self.exchange);
        self.exchange.offering = false;
        self.exchange.head = null;
        self.exchange.body_bytes = &.{};
        if (self.exchange.pending) return .waiting;
        return if (self.exchange.passed) .passed else .responded;
    }

    /// Drops the first `n` bytes of input: a request answered after its
    /// read callback.
    fn consumeInput(self: *Conn, n: usize) void {
        if (self.tls) |t| return t.consume(n);
        self.in_pos += n;
        self.compactInput();
    }

    /// An exchange's response, head and body in one send.
    fn answer(self: *Conn, status: u16, extra_headers: []const u8, body: []const u8) void {
        var buf: [4096]u8 = undefined;
        var w: std.Io.Writer = .fixed(&buf);
        const head = blk: {
            w.print("HTTP/1.1 {d} {s}\r\nContent-Length: {d}\r\n", .{ status, parser.reason(status), body.len }) catch break :blk null;
            w.writeAll(extra_headers) catch break :blk null;
            self.writeCommonHeaders(&w, !self.keep_alive) catch break :blk null;
            w.writeAll("\r\n") catch break :blk null;
            break :blk w.buffered();
        } orelse return self.respond(500, "Response headers too long", .close, null);
        self.sock.cork();
        self.output(head);
        if (!self.head_only) self.output(body);
        self.sock.uncork();
        self.responseDone();
    }

    /// Offers the request to `onHttpHead`; its slices are valid only there.
    fn startStream(self: *Conn, st: StreamHandlers, head: *const parser.RequestHead) enum { taken, passed } {
        self.phase = .stream;
        self.stream = .{
            .body = .of(head),
            .ex = .{
                .method = head.method,
                .target = head.target,
                .headers = head.headers,
                .content_length = if (head.chunked) null else head.content_length orelse 0,
                .head_only = self.head_only,
                .mailbox = &self.server.mailbox,
                .impl = self,
                .vtable = &stream_vtable,
            },
        };
        const s = &self.stream;
        st.head(self.server.handlers.ctx, &s.ex);
        s.ex.method = "";
        s.ex.target = "";
        s.ex.headers = &.{};
        if (s.ex.passed) {
            s.ex.answer = .done;
            self.phase = .head;
            return .passed;
        }
        if (!s.live()) return .taken;
        if (s.body.done) {
            self.endStream();
        } else {
            if (head.expect_continue) self.output("HTTP/1.1 100 Continue\r\n\r\n");
            self.body_window = .start(timers.nowMs(), self.server.config.stall_timeout_ms);
            self.armBodyWindow();
        }
        return .taken;
    }

    /// Hands the body in `buf` to `onHttpBody`; nothing past its end.
    fn processStreamBody(self: *Conn, buf: []u8) ?usize {
        const s = &self.stream;
        if (s.body.done or buf.len == 0) return null;
        const step = s.body.decode(buf) catch {
            self.finish(websocket.CloseCode.abnormal, .abort);
            return null;
        };
        if (self.body_window) |*w| w.got += step.consumed;
        const h = self.server.handlers;
        if (step.data.len > 0) h.stream.?.body(h.ctx, &s.ex, step.data);
        if (s.live() and s.body.done) self.endStream();
        return if (step.consumed > 0) step.consumed else null;
    }

    fn endStream(self: *Conn) void {
        self.body_window = null;
        self.armStream();
        const h = self.server.handlers;
        h.stream.?.end(h.ctx, &self.stream.ex);
    }

    const stream_vtable: Exchange.VTable = .{
        .peer = streamPeer,
        .head = streamHead,
        .body = streamBody,
        .end = streamEnd,
        .reset = streamReset,
        .buffered = streamBuffered,
        .cork = streamCork,
    };

    fn streamConn(ptr: *anyopaque) *Conn {
        return @ptrCast(@alignCast(ptr));
    }

    fn streamPeer(ptr: *anyopaque) *const posix.sockaddr.storage {
        return &streamConn(ptr).peer;
    }

    fn streamHead(ptr: *anyopaque, status: u16, headers: []const Header, framing: Exchange.Framing) Exchange.WriteError!void {
        const self = streamConn(ptr);
        // Answered before its body is in: no request can follow on this connection.
        if (!self.stream.body.done) self.keep_alive = false;
        var buf: [4096]u8 = undefined;
        var w: std.Io.Writer = .fixed(&buf);
        w.print("HTTP/1.1 {d} {s}\r\n", .{ status, parser.reason(status) }) catch return error.Closed;
        for (headers) |hd| if (!http.transportsOwn(hd.name)) w.print("{s}: {s}\r\n", .{ hd.name, hd.value }) catch return error.Closed;
        switch (framing) {
            .none => {},
            .length => |n| w.print("Content-Length: {d}\r\n", .{n}) catch return error.Closed,
            .unknown => if (self.http10) {
                self.keep_alive = false; // the body ends with the connection
            } else {
                w.writeAll("Transfer-Encoding: chunked\r\n") catch return error.Closed;
                self.stream.chunked = !self.head_only;
            },
        }
        self.writeCommonHeaders(&w, !self.keep_alive) catch return error.Closed;
        w.writeAll("\r\n") catch return error.Closed;
        self.output(w.buffered());
        if (!self.sock.isOpen()) return error.Closed;
    }

    fn streamBody(ptr: *anyopaque, data: []const u8) Exchange.WriteError!void {
        const self = streamConn(ptr);
        if (self.stream.chunked) {
            var size: [20]u8 = undefined;
            self.sock.cork();
            self.output(std.fmt.bufPrint(&size, "{x}\r\n", .{data.len}) catch unreachable);
            self.output(data);
            self.output("\r\n");
            self.sock.uncork();
        } else {
            self.output(data);
        }
        if (!self.sock.isOpen()) return error.Closed;
        if (!self.stream.full and self.sock.buffered() >= socket.low_water) {
            self.stream.full = true;
            self.armStream();
        }
    }

    /// Once the body is in, the stream's deadline: the handler's time,
    /// unless the client stops making room for the answer.
    fn armStream(self: *Conn) void {
        if (!self.stream.body.done) return; // its window's
        if (self.stream.full) return self.server.timers.set(&self.deadline, self.server.config.stall_timeout_ms);
        self.server.timers.clear(&self.deadline);
    }

    fn armBodyWindow(self: *Conn) void {
        const left = self.body_window.?.ends_ms - timers.nowMs();
        self.server.timers.set(&self.deadline, @intCast(std.math.clamp(left, 0, self.server.config.stall_timeout_ms)));
    }

    /// At its window's end: whether a request body still coming kept up.
    fn bodyKeptUp(self: *Conn) bool {
        const w = if (self.body_window) |*w| w else return false;
        return w.keptUp(timers.nowMs(), self.server.config.min_body_rate, self.server.config.stall_timeout_ms);
    }

    fn streamEnd(ptr: *anyopaque) void {
        const self = streamConn(ptr);
        if (self.stream.chunked) self.output("0\r\n\r\n");
        self.responseDone();
    }

    fn streamReset(ptr: *anyopaque) void {
        streamConn(ptr).enterClosing(.abort);
    }

    fn streamBuffered(ptr: *anyopaque) usize {
        return streamConn(ptr).sock.buffered();
    }

    fn streamCork(ptr: *anyopaque, on: bool) void {
        const self = streamConn(ptr);
        if (on) self.sock.cork() else self.sock.uncork();
    }

    /// The connection is the handler's from here on. Uses none of the
    /// head: `processRaw` hands it over, as the first bytes.
    fn startRaw(self: *Conn) usize {
        self.phase = .raw;
        self.raw = .{ .raw_id = self.server.nextId(), .notified = false };
        const h = self.server.handlers;
        h.raw.?.open(h.ctx, &self.raw);
        return 0;
    }

    /// The peer sent its last byte. The handler hears once all input before
    /// it is handed over: input paused for it comes first. With `onRawEnd`
    /// the connection stays open for its answer; without, it closes once
    /// what is queued has gone.
    fn rawEnd(self: *Conn) void {
        if (self.raw.ended or self.unreadLen() > 0) return;
        self.raw.ended = true;
        const h = self.server.handlers;
        if (h.raw.?.end) |end| return end(h.ctx, &self.raw);
        self.finish(websocket.CloseCode.normal, .graceful);
    }

    /// Hands all of `buf` to the handler's `onRawData`.
    fn processRaw(self: *Conn, buf: []u8) ?usize {
        if (buf.len == 0 or self.raw.paused) return null;
        const h = self.server.handlers;
        h.raw.?.data(h.ctx, &self.raw, buf);
        return buf.len;
    }

    fn handleUpgrade(self: *Conn, head: *const parser.RequestHead) void {
        const key = websocket.checkUpgrade(head) catch |err| switch (err) {
            error.BadRequest => return self.respond(400, "Bad WebSocket upgrade", .close, null),
            error.UnsupportedVersion => return self.respond(426, "Upgrade required", .close, "Sec-WebSocket-Version: 13\r\n"),
        };
        var req: WsRequest = .{ .conn = self, .head = head, .key = key };
        const h = self.server.handlers;
        h.upgrade.?(h.ctx, &req, head.target);
        if (req.decision == .pending) req.reject(403);
    }

    fn startWebSocket(self: *Conn) void {
        const cfg = self.server.config.websocket;
        self.phase = .ws_open;
        self.ws = .{
            .ws_id = self.server.nextId(),
            .decoder = .init(cfg.max_message_size),
            .notified = false,
        };
        self.server.ws_count += 1;
        if (cfg.ping_interval_ms > 0) self.server.timers.set(&self.deadline, cfg.ping_interval_ms);
    }

    /// Handles the frame at the start of `buf`, if all of it has arrived;
    /// returns its length. Event slices point into `buf`, which stays put
    /// until the handler returns.
    fn processFrame(self: *Conn, buf: []u8) ?usize {
        const step = self.ws.decoder.decode(self.server.alloc, buf) catch |err| {
            self.failWebSocket(websocket.closeCodeFor(err));
            return null;
        };
        if (step.consumed == 0) return null;
        const ev = step.event orelse return step.consumed;
        switch (ev) {
            .message => |m| {
                // §5.5.1: after our Close, data frames are discarded.
                if (self.phase == .ws_open and !self.ws.notified) {
                    const h = self.server.handlers;
                    self.in_message = true;
                    defer self.in_message = false;
                    h.message(h.ctx, &self.ws, m.data, m.kind);
                }
            },
            .ping => |payload| {
                if (self.phase == .ws_open) self.sendFrame(.pong, payload);
            },
            // Counted with the rest of rx_bytes, so a pong between the
            // fragments of a stalled message doesn't keep it alive.
            .pong => {},
            .close => |c| self.onPeerClose(c.code, c.reason),
        }
        return step.consumed;
    }

    fn onPeerClose(self: *Conn, code: ?u16, reason: []const u8) void {
        if (!self.ws.close_sent) {
            // Echo the code (§5.5.1), then close: the server closes TCP first.
            var p: [125]u8 = undefined;
            const payload: []const u8 = if (code) |c| websocket.closePayload(&p, c, "") else &.{};
            self.sendFrame(.close, payload);
            self.ws.close_sent = true;
        }
        self.notifyClose(code orelse websocket.CloseCode.no_status, reason);
        self.enterClosing(.graceful);
    }

    /// _Fail the WebSocket Connection_ (§7.1.7): a Close with the error's
    /// code, then the TCP connection closes.
    fn failWebSocket(self: *Conn, code: u16) void {
        if (!self.ws.close_sent) {
            var p: [125]u8 = undefined;
            self.sendFrame(.close, websocket.closePayload(&p, code, ""));
            self.ws.close_sent = true;
        }
        self.finish(code, .graceful);
    }

    fn onPingTimer(self: *Conn) void {
        const interval = self.server.config.websocket.ping_interval_ms;
        const alive = self.wsProgressed(interval);
        self.ws.rx_bytes = 0;
        self.ws.drained_mark = self.sock.drained;
        if (alive) {
            self.ws.ping_outstanding = false;
        } else if (self.ws.ping_outstanding) {
            // Silent for two intervals, pong included.
            return self.finish(websocket.CloseCode.abnormal, .abort);
        } else {
            self.sendFrame(.ping, "");
            self.ws.ping_outstanding = true;
            // Quiet for an interval: give back what large messages grew.
            if (self.in.items.len == self.in_pos) self.in.clearAndFree(self.server.alloc);
        }
        self.server.timers.set(&self.deadline, interval);
    }

    /// Whether the peer did enough since the last ping timer to count as
    /// alive. Idle, any byte will do; holding a partial message, or leaving
    /// our output unread, it must keep up `min_receive_rate`.
    fn wsProgressed(self: *Conn, interval_ms: u32) bool {
        // Paused, we read nothing: the peer's reading is what moves.
        const drained = if (self.sock.read_paused) self.sock.drained - self.ws.drained_mark else 0;
        const moved = self.ws.rx_bytes +| drained;
        const holding = self.unreadLen() > 0 or self.ws.decoder.fragment_kind != null or self.sock.read_paused;
        if (!holding) return moved > 0;
        const floor = @as(u64, self.server.config.websocket.min_receive_rate) * interval_ms / 1000;
        return moved >= @max(floor, 1);
    }

    // ─── WebSocket output ────────────────────────────────────────────

    fn sendFrame(self: *Conn, opcode: websocket.Opcode, payload: []const u8) void {
        var hdr_buf: [10]u8 = undefined;
        const hdr = websocket.writeFrameHeader(&hdr_buf, opcode, true, payload.len);
        if (self.tls == null and hdr.len + payload.len > coalesce_limit) {
            // One sendmsg for both, without copying the payload.
            return self.sock.writeVec(&.{ hdr, payload });
        }
        // Small frames, and the first TLS record of a large one: the header
        // travels with (the start of) the payload, not in a record of its own.
        var buf: [coalesce_limit]u8 = undefined;
        const head = @min(payload.len, buf.len - hdr.len);
        @memcpy(buf[0..hdr.len], hdr);
        @memcpy(buf[hdr.len..][0..head], payload[0..head]);
        self.output(buf[0 .. hdr.len + head]);
        self.output(payload[head..]);
    }

    fn sendMessage(self: *Conn, kind: websocket.MessageKind, data: []const u8) SendError!void {
        if (self.ws.notified or self.phase != .ws_open or !self.sock.isOpen()) return error.Closed;
        const max = self.server.config.websocket.max_send_buffer;
        if (self.sock.buffered() + data.len > max) {
            self.sock.flush(); // what a batch holds is no backlog of the peer's
            if (self.sock.buffered() + data.len > max) return error.SendBufferFull;
        }
        self.sendFrame(if (kind == .text) .text else .binary, data);
        // A failed write aborts; `onWsClose` follows from the deferred close.
        if (!self.sock.isOpen()) return error.Closed;
    }

    fn handOver(self: *Conn) HandoverError!void {
        if (self.server.handlers.handover == null) return error.HandoverNotConfigured;
        if (!self.in_message) return error.NotInMessage;
        if (self.ws.notified or self.phase != .ws_open or !self.sock.isOpen()) return error.Closed;
        self.phase = .moving;
        self.server.timers.clear(&self.deadline);
        self.sock.park();
    }

    /// `Server.adopt`: serve on `server`, on its loop's thread.
    pub fn moveTo(self: *Conn, server: *Server) void {
        self.server = server;
        if (self.tls) |t| if (server.tlsConfig()) |tc| {
            t.config = tc;
        };
        self.sock.rebind(server.loop, &server.timers);
        self.phase = .ws_open;
        const ping_ms = server.config.websocket.ping_interval_ms;
        if (ping_ms > 0) server.timers.set(&self.deadline, ping_ms);
        // After the handler has the WebSocket: what the old server left
        // unread comes after the message that moved it.
        server.timers.defer_(&self.resume_cb);
    }

    fn closeWebSocket(self: *Conn, code: u16, reason: []const u8) void {
        if (self.ws.notified or self.phase != .ws_open) return;
        const send_code = if (websocket.isValidCloseCode(code)) code else websocket.CloseCode.normal;
        var p: [125]u8 = undefined;
        self.sendFrame(.close, websocket.closePayload(&p, send_code, reason));
        self.ws.close_sent = true;
        self.phase = .ws_closing;
        self.server.timers.set(&self.deadline, close_timeout_ms);
    }

    /// For `Server.stop`: a Close with 1001 on an open WebSocket, then the
    /// connection goes. The frame is written directly when the socket has
    /// room; nothing waits for it.
    pub fn shutdown(self: *Conn) void {
        if ((self.phase == .ws_open or self.phase == .moving) and !self.ws.close_sent) {
            var p: [125]u8 = undefined;
            self.sendFrame(.close, websocket.closePayload(&p, websocket.CloseCode.going_away, ""));
            self.ws.close_sent = true;
        }
        self.finish(websocket.CloseCode.going_away, .abort);
    }

    /// For `Server.drain`: whether the connection holds no request in flight.
    pub fn isIdle(self: *Conn) bool {
        return switch (self.phase) {
            .head => self.unreadLen() == 0,
            .static_body, .exchange, .stream => false,
            .ws_open, .ws_closing, .raw, .closing, .moving => true,
        };
    }

    // ─── HTTP responses ──────────────────────────────────────────────

    const After = enum { keep, close };

    /// A short text/plain response. `extra` is preformatted header lines.
    fn respond(self: *Conn, status: u16, body: []const u8, after: After, extra: ?[]const u8) void {
        var buf: [1024]u8 = undefined;
        var w: std.Io.Writer = .fixed(&buf);
        const close = after == .close or !self.keep_alive;
        w.print("HTTP/1.1 {d} {s}\r\nContent-Type: text/plain; charset=utf-8\r\nContent-Length: {d}\r\n", .{
            status, parser.reason(status), body.len,
        }) catch unreachable;
        self.writeCommonHeaders(&w, close) catch unreachable;
        if (extra) |e| w.writeAll(e) catch unreachable;
        w.writeAll("\r\n") catch unreachable;
        if (!self.head_only) w.writeAll(body) catch unreachable;
        self.output(w.buffered());
        if (close) self.keep_alive = false;
        self.responseDone();
    }

    fn writeCommonHeaders(self: *Conn, w: *std.Io.Writer, close: bool) std.Io.Writer.Error!void {
        if (close) {
            try w.writeAll("Connection: close\r\n");
        } else if (self.http10) {
            try w.writeAll("Connection: keep-alive\r\n");
        }
        if (self.server.altSvc()) |v| try w.print("Alt-Svc: {s}\r\n", .{v});
    }

    fn serveStatic(self: *Conn, target: []const u8) void {
        const root = self.server.config.static_dir orelse return self.respond(404, "Not found", .keep, null);
        const path = target[0 .. std.mem.indexOfScalar(u8, target, '?') orelse target.len];
        if (path.len == 0 or path[0] != '/') return self.respond(400, "Bad request", .close, null);
        if (std.mem.indexOf(u8, path, "..") != null) return self.respond(403, "Forbidden", .keep, null);
        const rel = path[1..];

        var buf: [std.fs.max_path_bytes]u8 = undefined;
        const file, const full = openStatic(&buf, root, rel) orelse return self.respond(404, "Not found", .keep, null);
        if ((file.kind() catch .other) != .file) {
            file.close();
            return self.respond(404, "Not found", .keep, null);
        }
        const size = (file.stat() catch {
            file.close();
            return self.respond(500, "Cannot stat file", .keep, null);
        }).size;

        var hdr: [1024]u8 = undefined;
        var w: std.Io.Writer = .fixed(&hdr);
        w.print("HTTP/1.1 200 OK\r\nContent-Type: {s}\r\nContent-Length: {d}\r\n" ++
            "Access-Control-Allow-Origin: *\r\n" ++
            // Cross-origin isolation: sub-millisecond performance.now() in
            // Chrome, which the WebTransport demos time with.
            "Cross-Origin-Opener-Policy: same-origin\r\nCross-Origin-Embedder-Policy: require-corp\r\n", .{
            mimeType(full), size,
        }) catch unreachable;
        self.writeCommonHeaders(&w, !self.keep_alive) catch unreachable;
        w.writeAll("\r\n") catch unreachable;
        self.output(w.buffered());

        if (self.head_only or size == 0) {
            file.close();
            return self.responseDone();
        }
        self.file = file;
        self.file_remaining = size;
        self.phase = .static_body;
        self.pumpFile();
    }

    /// `{root}/{rel}`, with `index.html` for a directory path.
    fn openStatic(buf: []u8, root: []const u8, rel: []const u8) ?struct { sys.File, []const u8 } {
        const dir_path = rel.len == 0 or rel[rel.len - 1] == '/';
        const full = if (dir_path)
            std.fmt.bufPrint(buf, "{s}/{s}index.html", .{ root, rel }) catch return null
        else
            std.fmt.bufPrint(buf, "{s}/{s}", .{ root, rel }) catch return null;
        const opened: ?sys.File = sys.openFileRead(full) catch null;
        if (opened) |f| {
            if (dir_path or (f.kind() catch .other) != .directory) return .{ f, full };
            f.close();
        }
        if (dir_path) return null;
        // A directory named without its trailing slash.
        const index = std.fmt.bufPrint(buf, "{s}/{s}/index.html", .{ root, rel }) catch return null;
        const f = sys.openFileRead(index) catch return null;
        return .{ f, index };
    }

    fn pumpFile(self: *Conn) void {
        const file = self.file orelse return;
        var buf: [file_chunk]u8 = undefined;
        while (self.file_remaining > 0 and self.sock.isOpen() and self.sock.buffered() < socket.high_water) {
            const want: usize = @intCast(@min(self.file_remaining, buf.len));
            const n = file.read(buf[0..want]) catch 0;
            // The file shrank or failed mid-response: the length is a lie now.
            if (n == 0) return self.finish(websocket.CloseCode.abnormal, .abort);
            self.output(buf[0..n]);
            self.file_remaining -= n;
        }
        if (!self.sock.isOpen()) return;
        if (self.file_remaining > 0) {
            self.server.timers.set(&self.deadline, self.server.config.stall_timeout_ms);
            return;
        }
        self.closeFile();
        self.responseDone();
    }

    fn closeFile(self: *Conn) void {
        if (self.file) |f| f.close();
        self.file = null;
    }

    /// A response is fully queued: wait for the next request, or close.
    fn responseDone(self: *Conn) void {
        self.body_window = null;
        if (self.phase == .closing) return;
        if (!self.keep_alive or self.server.stopping) return self.enterClosing(.graceful);
        self.phase = .head;
        self.server.timers.set(&self.deadline, self.server.config.keepalive_timeout_ms);
        self.sock.resumeRead();
        // Pipelined requests already buffered.
        if (self.unreadLen() > 0) self.process();
    }
};

pub fn mimeType(path: []const u8) []const u8 {
    const ext = std.fs.path.extension(path);
    const table = [_]struct { []const u8, []const u8 }{
        .{ ".html", "text/html; charset=utf-8" },
        .{ ".htm", "text/html; charset=utf-8" },
        .{ ".css", "text/css; charset=utf-8" },
        .{ ".js", "application/javascript; charset=utf-8" },
        .{ ".mjs", "application/javascript; charset=utf-8" },
        .{ ".json", "application/json; charset=utf-8" },
        .{ ".png", "image/png" },
        .{ ".jpg", "image/jpeg" },
        .{ ".jpeg", "image/jpeg" },
        .{ ".gif", "image/gif" },
        .{ ".svg", "image/svg+xml" },
        .{ ".ico", "image/x-icon" },
        .{ ".woff2", "font/woff2" },
        .{ ".woff", "font/woff" },
        .{ ".wasm", "application/wasm" },
        .{ ".txt", "text/plain; charset=utf-8" },
        .{ ".xml", "application/xml" },
    };
    for (table) |e| {
        if (std.ascii.eqlIgnoreCase(ext, e[0])) return e[1];
    }
    return "application/octet-stream";
}

test "mime type lookup" {
    const expect = std.testing.expectEqualStrings;
    try expect("text/html; charset=utf-8", mimeType("index.html"));
    try expect("application/javascript; charset=utf-8", mimeType("app.js"));
    try expect("text/css; charset=utf-8", mimeType("style.css"));
    try expect("image/png", mimeType("logo.PNG"));
    try expect("application/octet-stream", mimeType("data.bin"));
}
