const std = @import("std");
const io = @import("../io_compat.zig");
const sys = @import("../sys.zig");
const posix = std.posix;
const log = std.log;
const time = std.time;
const assert = std.debug.assert;
// const tls = std.crypto.tls;

const protocol = @import("protocol.zig");
const crypto = @import("crypto.zig");
const util = @import("util.zig");
const stream = @import("stream.zig");

// network byte order
pub const ENDIAN = std.lang.Endian.big;

pub const LONG_HEADER_BIT: u8 = 0x80;
pub const FIXED_BIT: u8 = 0x40;
pub const KEY_PHASE_BIT: u8 = 0x04;

pub const PACKET_SPIN_BIT = 0x20;
pub const PACKET_TYPE_MASK = 0xF0;

pub const MAX_PACKET_LEN = 1536;
pub const MAX_PACKET_NUMBER_LEN = 4; // maxlength of a "packet number"

pub const CONNECTION_ID_MAX_SIZE: u8 = 20;

const PACKET_NUM_MASK: u8 = 0x03;

pub const STATELESS_RESET_TOKEN_SIZE = 16; // aren't these 2 the same?
pub const RETRY_INTEGRITY_TAG_SIZE = 16;
// RFC 9001 §5.8: QUIC v1 Retry integrity key/nonce
const RETRY_INTEGRITY_KEY_V1: [crypto.key_len]u8 = .{ 0xbe, 0x0c, 0x69, 0x0b, 0x9f, 0x66, 0x57, 0x5a, 0x1d, 0x76, 0x6b, 0x54, 0xe3, 0x68, 0xc8, 0x4e };
const RETRY_INTEGRITY_NONCE_V1: [crypto.nonce_len]u8 = .{ 0x46, 0x15, 0x99, 0xd3, 0x5d, 0x63, 0x2b, 0xf2, 0x23, 0x98, 0x25, 0xbb };
// RFC 9369 §3.2: QUIC v2 Retry integrity key/nonce
const RETRY_INTEGRITY_KEY_V2: [crypto.key_len]u8 = .{ 0x8f, 0xb4, 0xb0, 0x1b, 0x56, 0xac, 0x48, 0xe2, 0x60, 0xfb, 0xcb, 0xce, 0xad, 0x7c, 0xcc, 0x92 };
const RETRY_INTEGRITY_NONCE_V2: [crypto.nonce_len]u8 = .{ 0xd8, 0x69, 0x69, 0xbc, 0x2d, 0x7c, 0x6d, 0x99, 0x90, 0xef, 0xb0, 0x4a };

pub const PacketType = enum(u8) {
    /// Initial packet
    initial = LONG_HEADER_BIT | FIXED_BIT | 0x00,

    /// Retry packet
    retry = LONG_HEADER_BIT | FIXED_BIT | 0x30,

    /// Handshake packet
    handshake = LONG_HEADER_BIT | FIXED_BIT | 0x20,

    /// 0-RTT packet
    zero_rtt = LONG_HEADER_BIT | FIXED_BIT | 0x10,

    /// Version negotiation packet
    version_negotiation = 0,

    /// 1-RTT short header packet
    one_rtt = FIXED_BIT,

    _,
};

/// Map the 2-bit long header packet type field to a logical PacketType,
/// accounting for version-specific bit assignments.
/// RFC 9369 §5.1: v2 uses different bit patterns than v1.
pub fn longHeaderPacketType(first_byte: u8, version: u32) PacketType {
    const type_bits = (first_byte >> 4) & 0x03; // bits 4-5
    if (protocol.isV2(version)) {
        // v2: 0b00=Retry, 0b01=Initial, 0b10=0-RTT, 0b11=Handshake
        return switch (type_bits) {
            0b00 => PacketType.retry,
            0b01 => PacketType.initial,
            0b10 => PacketType.zero_rtt,
            0b11 => PacketType.handshake,
            else => unreachable,
        };
    }
    // v1: 0b00=Initial, 0b01=0-RTT, 0b10=Handshake, 0b11=Retry
    return switch (type_bits) {
        0b00 => PacketType.initial,
        0b01 => PacketType.zero_rtt,
        0b10 => PacketType.handshake,
        0b11 => PacketType.retry,
        else => unreachable,
    };
}

/// Encode the 2-bit long header packet type field for a given version.
pub fn encodeLongHeaderTypeBits(pkt_type: PacketType, version: u32) u8 {
    const bits: u8 = if (protocol.isV2(version)) switch (pkt_type) {
        PacketType.retry => 0b00,
        PacketType.initial => 0b01,
        PacketType.zero_rtt => 0b10,
        PacketType.handshake => 0b11,
        else => 0,
    } else switch (pkt_type) {
        PacketType.initial => 0b00,
        PacketType.zero_rtt => 0b01,
        PacketType.handshake => 0b10,
        PacketType.retry => 0b11,
        else => 0,
    };
    return LONG_HEADER_BIT | FIXED_BIT | (bits << 4);
}

pub const Epoch = enum(u8) {
    initial = 0,
    zero_rtt = 1,
    handshake = 2,
    application = 3,

    pub fn fromPacketType(int: PacketType) !Epoch {
        return switch (int) {
            PacketType.initial => Epoch.initial,
            PacketType.zero_rtt => Epoch.zero_rtt,
            PacketType.handshake => Epoch.handshake,
            PacketType.one_rtt => Epoch.application,
            else => error.InvalidPacketType,
        };
    }
};

test "Epoch fromPacketType" {
    try std.testing.expectEqual(Epoch.fromPacketType(PacketType.initial), Epoch.initial);
    try std.testing.expectEqual(Epoch.fromPacketType(PacketType.zero_rtt), Epoch.zero_rtt);
    try std.testing.expectEqual(Epoch.fromPacketType(PacketType.handshake), Epoch.handshake);
    try std.testing.expectEqual(Epoch.fromPacketType(PacketType.one_rtt), Epoch.application);

    const err = Epoch.fromPacketType(PacketType.retry);
    try std.testing.expectError(error.InvalidPacketType, err);
}

pub const PacketError = error{
    InvalidVersion,
    InvalidPacket,
    InvalidPacketType,
    InvalidVarLength,
};

pub const ErrorCode = enum(u16) {
    no_error = 0x0,
    internal_error = 0x1,
    connection_refused = 0x2,
    flow_control_error = 0x3,
    stream_limit_error = 0x4,
    stream_state_error = 0x5,
    final_size_error = 0x6,
    frame_encoding_error = 0x7,
    transport_parameter_error = 0x8,
    connection_id_limit_error = 0x9,
    protocol_violation = 0xa,
    invalid_token = 0xb,
    application_error = 0xc,
    crypto_buffer_exceeded = 0xd,
    key_update_error = 0xe,
    aead_limit_reached = 0xf,
    crypto_error = 0x100,
};

/// A QUIC packet's header.
pub const Header = struct {
    const Self = @This();

    version: u32 = 0,
    packet_type: PacketType = undefined,

    /// Destination Connection ID. Empty until the parser fills it — a short
    /// header whose DCID does not fit the datagram leaves it unset.
    dcid: []const u8 = &.{},

    /// Source Connection ID. Only a long header carries one, so this stays
    /// empty for every 1-RTT packet. It was `undefined`, which made reading it
    /// after a short-header parse depend on whatever was on the stack.
    scid: []const u8 = &.{},

    /// The address verification token of the packet. Only present in `Initial`
    /// and `Retry` packets.
    token: ?[]const u8 = null,
    remainder_len: usize = 0,

    /// The packet number. It's only meaningful after the header protection is
    /// removed.
    packet_number: u64 = 0,

    /// The length of the packet number. It's only meaningful after the header
    /// protection is removed.
    packet_number_len: usize = 0,

    /// The key phase bit of the packet. It's only meaningful after the header
    /// protection is removed.
    key_phase: bool = false,

    /// The spin bit for passive RTT measurement (RFC 9000 §17.4).
    /// Only meaningful for short (1-RTT) headers.
    spin_bit: bool = false,

    /// Whether reserved bits in the unprotected header are non-zero (RFC 9000 §17.2, §17.3).
    /// Set during header protection removal; checked in connection.recv().
    reserved_bits_set: bool = false,

    /// The offset of this packet's first byte within the buffer.
    /// Used to correctly handle coalesced packets.
    packet_start: usize = 0,

    pub fn parse(fbs: anytype, short_dcid_len: u8) !Header {
        return parseQuicHeader(fbs, short_dcid_len);
    }

    pub fn encode(self: *Self, writer: anytype) !void {
        var first: usize = 0;

        // encode pkt num length.
        first |= (self.packet_number_len -| 1); // (saturating sub)

        // encode short header
        if (self.packet_type == PacketType.one_rtt) {
            // unset form bit for short header
            first &= ~LONG_HEADER_BIT; // bitwise NOT

            // set fixed bit
            first |= FIXED_BIT;

            // set key phase bit
            if (self.key_phase) {
                first |= KEY_PHASE_BIT;
            } else {
                first &= ~KEY_PHASE_BIT; // bitwise NOT
            }

            try writer.writeByte(@intCast(first));
            try writer.writeAll(self.dcid);

            return;
        }

        // encode long header (version-aware type bits)
        // first already has pn_len bits from line 207; OR in the type+fixed+long bits
        first |= encodeLongHeaderTypeBits(self.packet_type, self.version);

        try writer.writeByte(@intCast(first));
        try writer.writeInt(u32, self.version, ENDIAN);

        try writer.writeByte(@intCast(self.dcid.len));
        try writer.writeAll(self.dcid);

        try writer.writeByte(@intCast(self.scid.len));
        try writer.writeAll(self.scid);

        // Only Initial and Retry packets have a token.
        switch (self.packet_type) {
            PacketType.initial => {
                if (self.token) |t| {
                    try writeVarInt(writer, t.len);
                    try writer.writeAll(t);
                } else {
                    try writeVarInt(writer, 0);
                }
            },

            PacketType.retry => {
                // retry packets don't have a token length.
                try writer.writeAll(self.token.?);
            },

            else => {}, // do nothing
        }
    }
};

pub const PktNumWindow = struct {
    lower: u64,
    window: u128,
};

pub const PacketNumSpace = struct {
    // largest_rx_pkt_num: u64,
    // largest_rx_pkt_time: time.Instant,
    //
    // next_pkt_num: u64,
    // // recv_pkt_need_ack: ranges::RangeSet,
    //
    // recv_pkt_num: PktNumWindow,
    // ack_elicited: bool,
    next_packet_number: u64 = 0, // TODO: largest_recv_packet_number

    crypto_open: ?crypto.Open = null,
    crypto_seal: ?crypto.Seal = null,

    // crypto_0rtt_open: Option<crypto::Open>,
    // crypto_0rtt_seal: Option<crypto::Seal>,

    // crypto_stream: stream.Stream = stream.Stream{},
    crypto_stream: stream.Stream = undefined,

    pub fn cryptoTagLen(self: *PacketNumSpace) usize {
        _ = self;
        return crypto.Aead.tag_length;
    }

    pub fn setupInitial(self: *PacketNumSpace, dcid: []const u8, version: u32, comptime is_server: bool) !void {
        const keys = try crypto.deriveInitialKeyMaterial(dcid, version, is_server);
        self.crypto_open = keys[0];
        self.crypto_seal = keys[1];
    }
};

/// Splits a protected packet into the Associated Data and the ciphertext
/// (RFC 9001 5.3: the AD is the header with its first byte unprotected).
///
/// Both lengths are the peer's to choose — the Length varint for the payload,
/// the token for the header — so neither is trusted here. A Length below the
/// packet number length underflows the subtraction, and one above the
/// datagram reads past it.
fn splitProtected(header: *const Header, fbs: anytype, first_byte: u8, ad_buf: []u8) !struct {
    ad: []const u8,
    payload: []u8,
} {
    if (fbs.seek > fbs.buffer.len) return error.InvalidPacket;
    if (header.remainder_len < header.packet_number_len) return error.InvalidPacket;

    const payload_len = header.remainder_len - header.packet_number_len;
    if (payload_len > fbs.buffer.len - fbs.seek) return error.InvalidPacket;

    const pkt_start = header.packet_start;
    if (pkt_start >= fbs.seek) return error.InvalidPacket;
    const header_len = fbs.seek - pkt_start;
    if (header_len > ad_buf.len) return error.InvalidPacket;

    ad_buf[0] = first_byte;
    @memcpy(ad_buf[1..][0 .. header_len - 1], fbs.buffer[pkt_start + 1 .. fbs.seek]);

    return .{
        .ad = ad_buf[0..header_len],
        .payload = fbs.buffer[fbs.seek..][0..payload_len],
    };
}

pub fn decrypt(header: *Header, fbs: anytype, space: *const PacketNumSpace) ![]u8 {
    // We need at least 4 bytes for packet number + 16 for sample
    if (fbs.seek + 4 + crypto.SAMPLE_LEN > fbs.buffer.len) {
        std.log.debug("Not enough data for packet number + sample: pos={d}, buffer.len={d}", .{ fbs.seek, fbs.buffer.len });
        return error.InvalidPacket;
    }

    var first_byte = fbs.buffer[header.packet_start];

    // unprotect header
    const aead = &space.crypto_open.?;

    // RFC 9001 Section 5.4.2: Sample is taken 4 bytes after START of packet number field
    const sample_offset = fbs.seek + 4;
    if (sample_offset + crypto.SAMPLE_LEN > fbs.buffer.len) {
        std.log.debug("Not enough data for sample: offset={d}, buffer.len={d}", .{ sample_offset, fbs.buffer.len });
        return error.InvalidPacket;
    }

    var sample_buf: [crypto.SAMPLE_LEN]u8 = undefined;
    @memcpy(&sample_buf, fbs.buffer[sample_offset..][0..crypto.SAMPLE_LEN]);

    const mask = aead.newMask(&sample_buf);

    if (isLongHeader(first_byte)) {
        first_byte ^= (mask[0] & 0x0f);
    } else {
        first_byte ^= (mask[0] & 0x1f);
    }

    // Check reserved bits after header protection removal (RFC 9000 §17.2, §17.3)
    if (isLongHeader(first_byte)) {
        header.reserved_bits_set = (first_byte & 0x0c) != 0;
    } else {
        header.reserved_bits_set = (first_byte & 0x18) != 0;
    }

    // Extract key phase and spin bits from unprotected short header (RFC 9001 §5.4.1, RFC 9000 §17.4)
    if (!isLongHeader(first_byte)) {
        header.key_phase = (first_byte & KEY_PHASE_BIT) != 0;
        header.spin_bit = (first_byte & PACKET_SPIN_BIT) != 0;
    }

    // Calculate packet number length from the unprotected first byte BEFORE using it
    header.packet_number_len = @as(usize, @intCast(first_byte & PACKET_NUM_MASK)) + 1;

    // Remove header protection from packet number bytes
    var i: usize = 0;
    while (i < header.packet_number_len) : (i += 1) {
        fbs.buffer[fbs.seek + i] ^= mask[1 + i];
    }

    // Now extract the decrypted packet number
    const pn_ciphertext: *const [MAX_PACKET_NUMBER_LEN]u8 = fbs.buffer[fbs.seek..][0..MAX_PACKET_NUMBER_LEN];

    // read truncated/raw packet number
    const truncated_packet_number: u64 = try switch (header.packet_number_len) {
        1 => @as(u64, std.mem.readInt(u8, pn_ciphertext.*[0..util.sizeOf(u8)], ENDIAN)),
        2 => @as(u64, std.mem.readInt(u16, pn_ciphertext.*[0..util.sizeOf(u16)], ENDIAN)),
        3 => @as(u64, std.mem.readInt(u24, pn_ciphertext.*[0..util.sizeOf(u24)], ENDIAN)),
        4 => @as(u64, std.mem.readInt(u32, pn_ciphertext.*[0..util.sizeOf(u32)], ENDIAN)),
        else => error.InvalidPacket,
    };

    // Skip the packet number bytes in the buffer
    try fbs.seekBy(@intCast(header.packet_number_len));

    // A header runs to the whole datagram when the peer sends a long token.
    var header_bytes_buf: [MAX_PACKET_LEN]u8 = undefined;
    const split = try splitProtected(header, fbs, first_byte, &header_bytes_buf);
    const header_bytes = split.ad;
    const encrypted_payload = split.payload;

    // Decode packet number
    header.packet_number = decodePacketNumber(space.next_packet_number, truncated_packet_number, header.packet_number_len * 8);

    const decrypted = try aead.decryptPayload(
        header.packet_number,
        header_bytes,
        encrypted_payload,
    );

    // Write decrypted first byte back into the input buffer for further processing.
    fbs.buffer[header.packet_start] = first_byte;

    return decrypted;
}

pub const Opened = struct {
    payload: []u8,
    /// The receive keys that opened it; `.next` means the peer updated.
    generation: crypto.KeyUpdateManager.Generation,
};

/// Decrypt a 1-RTT packet using the KeyUpdateManager for key phase handling.
/// Uses the (unchanging) HP key for header unprotection, then selects the
/// AEAD keys from the key phase bit and packet number (RFC 9001 §6.5).
pub fn decryptWithKeyUpdate(header: *Header, fbs: anytype, space: *const PacketNumSpace, ku: *crypto.KeyUpdateManager) !Opened {
    if (fbs.seek + 4 + crypto.SAMPLE_LEN > fbs.buffer.len) {
        return error.InvalidPacket;
    }

    var first_byte = fbs.buffer[header.packet_start];

    // Use the HP open key (never changes across key updates)
    const sample_offset = fbs.seek + 4;
    if (sample_offset + crypto.SAMPLE_LEN > fbs.buffer.len) {
        return error.InvalidPacket;
    }

    var sample_buf: [crypto.SAMPLE_LEN]u8 = undefined;
    @memcpy(&sample_buf, fbs.buffer[sample_offset..][0..crypto.SAMPLE_LEN]);

    // Generate mask using the invariant HP key (cipher-suite-aware).
    // Reuse the cached AES-128 round keys when available (AES suites).
    const mask_arr = blk: {
        if (ku.hp_open_ctx) |ctx| {
            var encrypted_out: [crypto.SAMPLE_LEN]u8 = undefined;
            ctx.encrypt(&encrypted_out, &sample_buf);
            break :blk encrypted_out[0..crypto.MASK_LEN].*;
        }
        break :blk crypto.computeHpMask(&sample_buf, ku.hp_open, ku.cipher_suite);
    };
    const mask = &mask_arr;

    // Short header unmasking
    first_byte ^= (mask[0] & 0x1f);

    // Check reserved bits (RFC 9000 §17.3)
    header.reserved_bits_set = (first_byte & 0x18) != 0;

    // Extract key phase and spin bits from unprotected first byte
    header.key_phase = (first_byte & KEY_PHASE_BIT) != 0;
    header.spin_bit = (first_byte & PACKET_SPIN_BIT) != 0;

    header.packet_number_len = @as(usize, @intCast(first_byte & PACKET_NUM_MASK)) + 1;

    // Unmask packet number bytes
    var i: usize = 0;
    while (i < header.packet_number_len) : (i += 1) {
        fbs.buffer[fbs.seek + i] ^= mask[1 + i];
    }

    // Extract truncated packet number
    const pn_ciphertext: *const [MAX_PACKET_NUMBER_LEN]u8 = fbs.buffer[fbs.seek..][0..MAX_PACKET_NUMBER_LEN];
    const truncated_packet_number: u64 = try switch (header.packet_number_len) {
        1 => @as(u64, std.mem.readInt(u8, pn_ciphertext.*[0..util.sizeOf(u8)], ENDIAN)),
        2 => @as(u64, std.mem.readInt(u16, pn_ciphertext.*[0..util.sizeOf(u16)], ENDIAN)),
        3 => @as(u64, std.mem.readInt(u24, pn_ciphertext.*[0..util.sizeOf(u24)], ENDIAN)),
        4 => @as(u64, std.mem.readInt(u32, pn_ciphertext.*[0..util.sizeOf(u32)], ENDIAN)),
        else => error.InvalidPacket,
    };

    try fbs.seekBy(@intCast(header.packet_number_len));

    var header_bytes_buf: [MAX_PACKET_LEN]u8 = undefined;
    const split = try splitProtected(header, fbs, first_byte, &header_bytes_buf);
    const header_bytes = split.ad;
    const encrypted_payload = split.payload;

    // Decode packet number
    header.packet_number = decodePacketNumber(space.next_packet_number, truncated_packet_number, header.packet_number_len * 8);

    const generation = ku.generationFor(header.key_phase, header.packet_number);
    const decrypted = try ku.openKeys(generation).decryptPayload(
        header.packet_number,
        header_bytes,
        encrypted_payload,
    );

    fbs.buffer[header.packet_start] = first_byte;

    return .{ .payload = decrypted, .generation = generation };
}

// inline
pub fn isLongHeader(first_byte: u8) bool {
    return (first_byte & LONG_HEADER_BIT) == LONG_HEADER_BIT;
}

pub fn parseQuicHeader(fbs: anytype, short_dcid_len: u8) !Header {
    const packet_start_pos = fbs.seek;
    const first_byte = try fbs.takeByte();

    var header = Header{};
    header.packet_start = packet_start_pos;

    if (isLongHeader(first_byte)) {
        // Long header packet

        const version = try fbs.takeInt(u32, ENDIAN);
        header.version = version;

        const dcid_length = try fbs.takeByte();
        if (dcid_length > CONNECTION_ID_MAX_SIZE) {
            std.log.debug("Destination CID is too long ({any} bytes)", .{dcid_length});
            return error.PacketError;
        }
        if (fbs.seek + dcid_length > fbs.buffer.len) return error.BufferTooShort;

        header.dcid = fbs.buffer[fbs.seek..(fbs.seek + dcid_length)];

        // advance length
        fbs.seek += dcid_length;

        const scid_length = try fbs.takeByte();
        if (scid_length > CONNECTION_ID_MAX_SIZE) {
            std.log.debug("Source CID is too long ({any} bytes)", .{scid_length});
            return error.InvalidPacket;
        }
        if (fbs.seek + scid_length > fbs.buffer.len) return error.BufferTooShort;

        header.scid = fbs.buffer[fbs.seek..(fbs.seek + scid_length)];

        // advance scid_length
        fbs.seek += scid_length;

        if ((first_byte & FIXED_BIT) == 0) {
            std.log.debug("Packet fixed bit is zero", .{});
            return error.InvalidPacket;
        }

        // Use version-aware packet type mapping (v1 vs v2 bit patterns differ)
        if (version == 0) {
            header.packet_type = PacketType.version_negotiation;
        } else {
            header.packet_type = longHeaderPacketType(first_byte, version);
        }

        switch (header.packet_type) {
            PacketType.initial => {
                // NOTE: RFC 9000 Section 8.1 requires clients to send Initial packets
                // with at least 1200 bytes payload. This is validated when sending (in packet_packer),
                // not when receiving, since the server may send smaller Initial packets.

                const token_length = try readVarInt(fbs);
                if (token_length > 0) {
                    // compare in u64: seek + token_length would overflow a 32-bit usize
                    if (token_length > fbs.buffer.len - fbs.seek) return error.BufferTooShort;
                    const n: usize = @intCast(token_length);
                    header.token = fbs.buffer[fbs.seek..][0..n];
                    fbs.seek += n;
                }

                header.remainder_len = try readVarIntUsize(fbs);
            },

            PacketType.retry => {
                // Retry packet: everything after header, before 16-byte integrity tag, is the token
                const remaining = fbs.buffer.len - fbs.seek;
                if (remaining > RETRY_INTEGRITY_TAG_SIZE) {
                    header.token = fbs.buffer[fbs.seek .. fbs.buffer.len - RETRY_INTEGRITY_TAG_SIZE];
                }
                // Retry packets have no Length field — they consume the entire datagram
                header.remainder_len = remaining;
            },

            // The supported-versions list runs to the end of the datagram.
            PacketType.version_negotiation => header.remainder_len = fbs.buffer.len - fbs.seek,

            PacketType.handshake, PacketType.zero_rtt => {
                // Long header packets (like Initial but without Token field)
                header.remainder_len = try readVarIntUsize(fbs);
            },

            PacketType.one_rtt => {
                // Short header packet (1-RTT)
                if (fbs.seek + short_dcid_len <= fbs.buffer.len) {
                    header.dcid = fbs.buffer[fbs.seek..(fbs.seek + short_dcid_len)];
                    fbs.seek += short_dcid_len;
                }

                header.remainder_len = fbs.buffer.len - fbs.seek;
            },

            else => {
                std.log.debug("Packet type not recognized: {any}", .{header.packet_type});
                header.remainder_len = try readVarIntUsize(fbs);
            },
        }
    } else {
        // Short header (1-RTT) packet

        header.packet_type = PacketType.one_rtt;

        // Short header: first_byte + DCID (known length from connection state) + payload
        if (fbs.seek + short_dcid_len <= fbs.buffer.len) {
            header.dcid = fbs.buffer[fbs.seek..(fbs.seek + short_dcid_len)];
            fbs.seek += short_dcid_len;
        }

        header.remainder_len = fbs.buffer.len - fbs.seek;
    }

    return header;
}

pub fn negotiateVersion(header: Header, writer: anytype) !void {
    try writer.writeByte(sys.randomInt(u8) | LONG_HEADER_BIT);
    try writer.writeInt(u32, 0, ENDIAN);

    try writer.writeByte(@intCast(header.scid.len));
    try writer.writeAll(header.scid);

    try writer.writeByte(@intCast(header.dcid.len));
    try writer.writeAll(header.dcid);

    for (protocol.SUPPORTED_VERSIONS) |version| {
        try writer.writeInt(u32, version, ENDIAN);
    }

    // RFC 9000 §6.3: Include a reserved version for greasing.
    // Reserved versions follow the pattern 0x?a?a?a?a.
    var grease_bytes: [2]u8 = undefined;
    sys.randomBytes(&grease_bytes);
    const grease_version: u32 = (@as(u32, grease_bytes[0] >> 4) << 28) | (0xa << 24) |
        (@as(u32, grease_bytes[0] & 0xf) << 20) | (0xa << 16) |
        (@as(u32, grease_bytes[1] >> 4) << 12) | (0xa << 8) |
        (@as(u32, grease_bytes[1] & 0xf) << 4) | 0xa;
    try writer.writeInt(u32, grease_version, ENDIAN);
}

pub fn retry(
    header: Header,
    new_scid: []u8, // original destination connection id
    token: []u8,
    fbs: anytype,
) !void {
    const writer = fbs;
    var hdr = Header{
        .version = header.version,
        .packet_type = PacketType.retry,
        .dcid = header.scid,
        .scid = new_scid,
        .token = token,
        .packet_number = 0,
        .packet_number_len = 0,
    };

    try hdr.encode(writer);

    const integrity_tag = try computeRetryIntegrityTag(fbs.buffered(), header.dcid, header.version);

    try writer.writeAll(&integrity_tag);
}

///
/// Compute the integrity tag for a RETRY packet.
///
/// ---------------------------------------------
///
/// Retry packets carry a Retry Integrity Tag that provides two properties: it
/// allows the discarding of packets that have accidentally been corrupted by the
/// network, and only an entity that observes an Initial packet can send a valid
/// Retry packet.
///
/// - Retry Packets: https://datatracker.ietf.org/doc/html/rfc9000#section-17.2.5
/// - Retry Packet Integrity: https://datatracker.ietf.org/doc/html/rfc9001#section-5.8
///
pub fn computeRetryIntegrityTag(
    packet_bytes_without_tag: []const u8,
    odcid: []const u8,
    version: u32,
) ![crypto.Aead.tag_length]u8 {
    const key = if (protocol.isV2(version)) RETRY_INTEGRITY_KEY_V2 else RETRY_INTEGRITY_KEY_V1;
    const nonce = if (protocol.isV2(version)) RETRY_INTEGRITY_NONCE_V2 else RETRY_INTEGRITY_NONCE_V1;

    // Use stack buffer: 1 (odcid_len) + 20 (max odcid) + ~1300 (max packet) = 1321
    var buf: [1400]u8 = undefined;
    var inner_fbs = io.fixedBufferStream(&buf);
    const buf_writer = &inner_fbs;
    try buf_writer.writeByte(@intCast(odcid.len));
    try buf_writer.writeAll(odcid);
    try buf_writer.writeAll(packet_bytes_without_tag);

    const m = "";
    var c: [m.len]u8 = undefined;
    var tag: [crypto.Aead.tag_length]u8 = undefined;
    crypto.Aead.encrypt(&c, &tag, m, inner_fbs.buffered(), nonce, key);

    return tag;
}

// Verify the integrity tag of a received Retry packet.
pub fn verifyRetryIntegrity(
    raw_packet: []const u8,
    odcid: []const u8,
    version: u32,
) !bool {
    if (raw_packet.len < RETRY_INTEGRITY_TAG_SIZE) return false;
    const packet_without_tag = raw_packet[0 .. raw_packet.len - RETRY_INTEGRITY_TAG_SIZE];
    const received_tag = raw_packet[raw_packet.len - RETRY_INTEGRITY_TAG_SIZE ..];
    const expected_tag = try computeRetryIntegrityTag(packet_without_tag, odcid, version);
    // Constant-time compare of the Retry integrity AEAD tag (RFC 9001 §5.8):
    // a non-constant-time check is an authentication-tag oracle.
    return std.crypto.timing_safe.eql([RETRY_INTEGRITY_TAG_SIZE]u8, received_tag[0..RETRY_INTEGRITY_TAG_SIZE].*, expected_tag);
}

// Encrypted Retry token format:
// nonce(12) || AES-128-GCM-encrypt(plaintext) || tag(16)
// Plaintext: odcid_len(1) + odcid(<=20) + retry_scid_len(1) + retry_scid(<=20) + timestamp_ns(8) + addr_binding(18)
pub const TOKEN_NONCE_LEN = 12;
pub const TOKEN_TAG_LEN = 16;
pub const TOKEN_MAX_PLAINTEXT_LEN = 1 + 20 + 1 + 20 + 8 + ADDR_BINDING_LEN; // 68
pub const TOKEN_MAX_LEN = TOKEN_NONCE_LEN + TOKEN_MAX_PLAINTEXT_LEN + TOKEN_TAG_LEN; // 96

const ADDR_BINDING_LEN = 2 + 16;

pub const v4_mapped_prefix = @as([10]u8, @splat(0)) ++ [_]u8{ 0xff, 0xff };

/// The client's IP as 16 bytes, IPv4 in its v4-mapped form so either socket
/// family gives the same bytes.
pub fn mappedIp(addr: *const posix.sockaddr.storage) [16]u8 {
    const raw = std.mem.asBytes(addr);
    if (addr.family == posix.AF.INET6) {
        return std.mem.bytesToValue(posix.sockaddr.in6, raw[0..@sizeOf(posix.sockaddr.in6)]).addr;
    }
    const in4 = std.mem.bytesToValue(posix.sockaddr.in, raw[0..@sizeOf(posix.sockaddr.in)]);
    return v4_mapped_prefix ++ @as([4]u8, @bitCast(in4.addr));
}

/// The client address a token is bound to: port, then `mappedIp`.
fn addrBinding(addr: *const posix.sockaddr.storage) [ADDR_BINDING_LEN]u8 {
    const raw = std.mem.asBytes(addr);
    const port = if (addr.family == posix.AF.INET6)
        std.mem.bytesToValue(posix.sockaddr.in6, raw[0..@sizeOf(posix.sockaddr.in6)]).port
    else
        std.mem.bytesToValue(posix.sockaddr.in, raw[0..@sizeOf(posix.sockaddr.in)]).port;
    return @as([2]u8, @bitCast(port)) ++ mappedIp(addr);
}

pub fn generateRetryToken(
    out: []u8,
    odcid: []const u8,
    retry_scid: []const u8,
    client_addr: posix.sockaddr.storage,
    token_key: [crypto.key_len]u8,
) !usize {
    if (out.len < TOKEN_MAX_LEN) return error.BufferTooSmall;

    // Generate random nonce
    var nonce: [TOKEN_NONCE_LEN]u8 = undefined;
    sys.randomBytes(&nonce);
    @memcpy(out[0..TOKEN_NONCE_LEN], &nonce);

    // Build plaintext
    var plaintext: [TOKEN_MAX_PLAINTEXT_LEN]u8 = undefined;
    var pt_fbs = io.fixedBufferStream(&plaintext);
    const pt_writer = &pt_fbs;
    try pt_writer.writeByte(@intCast(odcid.len));
    try pt_writer.writeAll(odcid);
    try pt_writer.writeByte(@intCast(retry_scid.len));
    try pt_writer.writeAll(retry_scid);
    const now: i64 = @intCast(sys.nanoTimestamp());
    try pt_writer.writeInt(i64, now, ENDIAN);
    try pt_writer.writeAll(&addrBinding(&client_addr));

    const pt_len = pt_fbs.seek;
    const pt_data = plaintext[0..pt_len];

    var ciphertext_buf: [TOKEN_MAX_PLAINTEXT_LEN]u8 = undefined;
    var tag: [TOKEN_TAG_LEN]u8 = undefined;
    crypto.Aead.encrypt(
        ciphertext_buf[0..pt_len],
        &tag,
        pt_data,
        RETRY_TOKEN_AD,
        nonce,
        token_key,
    );

    @memcpy(out[TOKEN_NONCE_LEN..][0..pt_len], ciphertext_buf[0..pt_len]);
    @memcpy(out[TOKEN_NONCE_LEN + pt_len ..][0..TOKEN_TAG_LEN], &tag);

    return TOKEN_NONCE_LEN + pt_len + TOKEN_TAG_LEN;
}

pub const ValidatedToken = struct {
    odcid_buf: [20]u8 = @splat(0),
    odcid_len: u8 = 0,
    retry_scid_buf: [20]u8 = @splat(0),
    retry_scid_len: u8 = 0,

    pub fn getOdcid(self: *const ValidatedToken) []const u8 {
        return self.odcid_buf[0..self.odcid_len];
    }

    pub fn getRetryScid(self: *const ValidatedToken) []const u8 {
        return self.retry_scid_buf[0..self.retry_scid_len];
    }
};

// Token validity duration: 60 seconds
const TOKEN_MAX_AGE_NS: i64 = 60 * std.time.ns_per_s;

// Both token kinds share one key; the AD keeps either from opening as the other.
const RETRY_TOKEN_AD = "quic-zig retry token";
const NEW_TOKEN_AD = "quic-zig new token";

fn tokenFresh(timestamp: i64) bool {
    const now: i64 = @intCast(sys.nanoTimestamp());
    return timestamp <= now and timestamp >= now - TOKEN_MAX_AGE_NS;
}

/// The token's contents, if it is a fresh Retry token of ours for
/// `client_addr` on an Initial to `dcid`. The client sends to the SCID its
/// Retry gave (RFC 9000 7.2), so under any other DCID the token is a replay,
/// good only for opening connections nobody was asked to prove.
pub fn validateRetryToken(
    token_data: []const u8,
    dcid: []const u8,
    client_addr: posix.sockaddr.storage,
    token_key: [crypto.key_len]u8,
) !?ValidatedToken {
    // A longer token is none of ours, and would overrun `plaintext`.
    if (token_data.len < TOKEN_NONCE_LEN + TOKEN_TAG_LEN + 2 or token_data.len > TOKEN_MAX_LEN) return null;

    const nonce = token_data[0..TOKEN_NONCE_LEN].*;
    const ct_len = token_data.len - TOKEN_NONCE_LEN - TOKEN_TAG_LEN;
    const ciphertext = token_data[TOKEN_NONCE_LEN..][0..ct_len];
    const tag = token_data[token_data.len - TOKEN_TAG_LEN ..][0..TOKEN_TAG_LEN].*;

    // Decrypt
    var plaintext: [TOKEN_MAX_PLAINTEXT_LEN]u8 = undefined;
    crypto.Aead.decrypt(
        plaintext[0..ct_len],
        ciphertext,
        tag,
        RETRY_TOKEN_AD,
        nonce,
        token_key,
    ) catch return null; // decryption failed = invalid token

    // Parse plaintext
    var pt_fbs = io.fixedBufferStream(plaintext[0..ct_len]);
    const pt_reader = &pt_fbs;

    var result = ValidatedToken{};

    // Read ODCID
    result.odcid_len = pt_reader.takeByte() catch return null;
    if (result.odcid_len > 20) return null;
    _ = pt_reader.readSliceShort(result.odcid_buf[0..result.odcid_len]) catch return null;

    // Read retry SCID
    result.retry_scid_len = pt_reader.takeByte() catch return null;
    if (result.retry_scid_len > 20) return null;
    _ = pt_reader.readSliceShort(result.retry_scid_buf[0..result.retry_scid_len]) catch return null;
    if (!std.mem.eql(u8, result.getRetryScid(), dcid)) return null;

    // Read timestamp and check age
    const timestamp = pt_reader.takeInt(i64, ENDIAN) catch return null;
    if (!tokenFresh(timestamp)) return null;

    const bound = pt_reader.takeArray(ADDR_BINDING_LEN) catch return null;
    if (!std.mem.eql(u8, bound, &addrBinding(&client_addr))) return null;

    return result;
}

// NEW_TOKEN token format (RFC 9000 §8.1.3):
// nonce(12) || AES-128-GCM-encrypt(plaintext) || tag(16)
// Plaintext: timestamp_ns(8) + mappedIp(16) = 24 bytes
// Distinguishable from Retry tokens by shorter ciphertext.
// The IP without the port (RFC 9000 8.1.4): the client's next connection
// comes from a port of its own, and under SO_REUSEPORT often to another server.
const NEW_TOKEN_PLAINTEXT_LEN: usize = 8 + 16;
const NEW_TOKEN_MAX_LEN: usize = TOKEN_NONCE_LEN + NEW_TOKEN_PLAINTEXT_LEN + TOKEN_TAG_LEN; // 52

pub fn generateNewToken(
    out: []u8,
    client_addr: posix.sockaddr.storage,
    token_key: [crypto.key_len]u8,
) !usize {
    if (out.len < NEW_TOKEN_MAX_LEN) return error.BufferTooSmall;

    var nonce: [TOKEN_NONCE_LEN]u8 = undefined;
    sys.randomBytes(&nonce);
    @memcpy(out[0..TOKEN_NONCE_LEN], &nonce);

    var plaintext: [NEW_TOKEN_PLAINTEXT_LEN]u8 = undefined;
    var pt_fbs = io.fixedBufferStream(&plaintext);
    const pt_writer = &pt_fbs;
    const now: i64 = @intCast(sys.nanoTimestamp());
    try pt_writer.writeInt(i64, now, ENDIAN);
    try pt_writer.writeAll(&mappedIp(&client_addr));

    var ciphertext_buf: [NEW_TOKEN_PLAINTEXT_LEN]u8 = undefined;
    var tag: [TOKEN_TAG_LEN]u8 = undefined;
    crypto.Aead.encrypt(
        &ciphertext_buf,
        &tag,
        &plaintext,
        NEW_TOKEN_AD,
        nonce,
        token_key,
    );

    @memcpy(out[TOKEN_NONCE_LEN..][0..NEW_TOKEN_PLAINTEXT_LEN], &ciphertext_buf);
    @memcpy(out[TOKEN_NONCE_LEN + NEW_TOKEN_PLAINTEXT_LEN ..][0..TOKEN_TAG_LEN], &tag);

    return NEW_TOKEN_MAX_LEN;
}

/// A NEW_TOKEN token's size, which no Retry token of ours has (those carry
/// a DCID of at least 8 bytes): an invalid one is told apart by it.
pub fn isNewTokenSized(token: []const u8) bool {
    return token.len == NEW_TOKEN_MAX_LEN;
}

pub fn validateNewToken(
    token_data: []const u8,
    client_addr: posix.sockaddr.storage,
    token_key: [crypto.key_len]u8,
) bool {
    if (token_data.len != NEW_TOKEN_MAX_LEN) return false;

    const nonce = token_data[0..TOKEN_NONCE_LEN].*;
    const ciphertext = token_data[TOKEN_NONCE_LEN..][0..NEW_TOKEN_PLAINTEXT_LEN];
    const tag = token_data[token_data.len - TOKEN_TAG_LEN ..][0..TOKEN_TAG_LEN].*;

    var plaintext: [NEW_TOKEN_PLAINTEXT_LEN]u8 = undefined;
    crypto.Aead.decrypt(
        &plaintext,
        ciphertext,
        tag,
        NEW_TOKEN_AD,
        nonce,
        token_key,
    ) catch return false;

    var pt_fbs = io.fixedBufferStream(&plaintext);
    const pt_reader = &pt_fbs;

    const timestamp = pt_reader.takeInt(i64, ENDIAN) catch return false;
    if (!tokenFresh(timestamp)) return false;

    const bound = pt_reader.takeArray(16) catch return false;
    if (!std.mem.eql(u8, bound, &mappedIp(&client_addr))) return false;

    return true;
}

pub fn readVarInt(reader: anytype) !u64 {
    //
    // https://datatracker.ietf.org/doc/html/draft-ietf-quic-transport-16#section-16
    //
    //     For example, the eight octet sequence c2 19 7c 5e ff 14 e8 8c (in
    //     hexadecimal) decodes to the decimal value 151288809941952652; the
    //     four octet sequence 9d 7f 3e 7d decodes to 494878333; the two octet
    //     sequence 7b bd decodes to 15293; and the single octet 25 decodes to
    //     37 (as does the two octet sequence 40 25).
    //
    const first_byte = try reader.takeByte();

    // the first two bits of the first byte encode the length
    var len: i32 = @as(i32, 1) << @intCast((first_byte & 0xc0) >> 6);
    len = len - 1;

    var value: u64 = first_byte & 0x3F;
    while (len > 0) {
        len = len - 1;
        value = (value << 8);

        const red = try reader.takeByte();
        value = value + red;
    }

    return value;
}

/// Returns the number of bytes needed to encode a value as a QUIC variable-length integer.
/// Read a varint that will be used as a length or index. Wire varints are
/// u64; anything that cannot be a usize cannot describe a real buffer.
pub fn readVarIntUsize(reader: anytype) !usize {
    return std.math.cast(usize, try readVarInt(reader)) orelse error.VarIntTooLarge;
}

pub fn varIntLength(value: u64) usize {
    if (value <= 63) return 1;
    if (value <= 16383) return 2;
    if (value <= 1073741823) return 4;
    return 8;
}

/// Writes a QUIC variable-length integer (RFC 9000 Section 16).
pub fn writeVarInt(writer: anytype, value: u64) !void {
    if (value <= 63) {
        // 1-byte encoding: 00xxxxxx
        try writer.writeByte(@intCast(value));
    } else if (value <= 16383) {
        // 2-byte encoding: 01xxxxxx xxxxxxxx
        try writer.writeInt(u16, @intCast(value | (0b01 << 14)), ENDIAN);
    } else if (value <= 1073741823) {
        // 4-byte encoding: 10xxxxxx xxxxxxxx xxxxxxxx xxxxxxxx
        try writer.writeInt(u32, @intCast(value | (0b10 << 30)), ENDIAN);
    } else if (value <= 4611686018427387903) {
        // 8-byte encoding: 11xxxxxx xxxxxxxx ... xxxxxxxx
        try writer.writeInt(u64, value | (0b11 << 62), ENDIAN);
    } else {
        return error.VarIntTooLarge;
    }
}

test "QUIC: a parsed header hands back real slices, even where it filled none" {
    // Both defaulted to `undefined`, so a caller that read `scid` after a
    // short-header parse read the stack. The randomized sweeps found it as a
    // usize overflow in one test and a failed @intCast in another, on Linux
    // only — which is what reading undefined memory looks like.
    {
        // Short header: one byte of flags, then a DCID the caller sizes.
        const short = [_]u8{ 0x40, 0xde, 0xad, 0xbe, 0xef, 0x01, 0x02, 0x03, 0x04, 0xff };
        var fbs = io.fixedBufferStream(&short);
        const hdr = try Header.parse(&fbs, 8);
        try std.testing.expectEqual(PacketType.one_rtt, hdr.packet_type);
        try std.testing.expectEqual(@as(usize, 0), hdr.scid.len);
        try std.testing.expectEqual(@as(usize, 8), hdr.dcid.len);
    }
    {
        // ... and a DCID that does not fit leaves that one empty too.
        const truncated = [_]u8{ 0x40, 0xde, 0xad };
        var fbs = io.fixedBufferStream(&truncated);
        const hdr = try Header.parse(&fbs, 8);
        try std.testing.expectEqual(@as(usize, 0), hdr.dcid.len);
        try std.testing.expectEqual(@as(usize, 0), hdr.scid.len);
    }
}

test "QUIC: Variable-Length Integer Encoding" {
    // 1-byte encoding
    {
        var buf: [8]u8 = undefined;
        var fbs = io.fixedBufferStream(&buf);
        try writeVarInt(&fbs, 37);
        try std.testing.expectEqualSlices(u8, &[_]u8{0x25}, fbs.buffered());
    }
    // 2-byte encoding
    {
        var buf: [8]u8 = undefined;
        var fbs = io.fixedBufferStream(&buf);
        try writeVarInt(&fbs, 15293);
        try std.testing.expectEqualSlices(u8, &[_]u8{ 0x7b, 0xbd }, fbs.buffered());
    }
    // 4-byte encoding
    {
        var buf: [8]u8 = undefined;
        var fbs = io.fixedBufferStream(&buf);
        try writeVarInt(&fbs, 494878333);
        try std.testing.expectEqualSlices(u8, &[_]u8{ 0x9d, 0x7f, 0x3e, 0x7d }, fbs.buffered());
    }
    // 8-byte encoding
    {
        var buf: [8]u8 = undefined;
        var fbs = io.fixedBufferStream(&buf);
        try writeVarInt(&fbs, 151288809941952652);
        try std.testing.expectEqualSlices(u8, &[_]u8{ 0xc2, 0x19, 0x7c, 0x5e, 0xff, 0x14, 0xe8, 0x8c }, fbs.buffered());
    }
}

test "QUIC: varIntLength" {
    try std.testing.expectEqual(@as(usize, 1), varIntLength(0));
    try std.testing.expectEqual(@as(usize, 1), varIntLength(63));
    try std.testing.expectEqual(@as(usize, 2), varIntLength(64));
    try std.testing.expectEqual(@as(usize, 2), varIntLength(16383));
    try std.testing.expectEqual(@as(usize, 4), varIntLength(16384));
    try std.testing.expectEqual(@as(usize, 4), varIntLength(1073741823));
    try std.testing.expectEqual(@as(usize, 8), varIntLength(1073741824));
}

test "QUIC: Variable-Length Integer Decoding" {
    var fbs = io.fixedBufferStream(&[_]u8{ 0xc2, 0x19, 0x7c, 0x5e, 0xff, 0x14, 0xe8, 0x8c });
    try std.testing.expect(151288809941952652 == try readVarInt(&fbs));

    fbs = io.fixedBufferStream(&[_]u8{ 0x9d, 0x7f, 0x3e, 0x7d });
    try std.testing.expect(494878333 == try readVarInt(&fbs));

    fbs = io.fixedBufferStream(&[_]u8{ 0x7b, 0xbd });
    try std.testing.expect(15293 == try readVarInt(&fbs));

    fbs = io.fixedBufferStream(&[_]u8{0x25});
    try std.testing.expect(37 == try readVarInt(&fbs));

    fbs = io.fixedBufferStream(&[_]u8{ 0x40, 0x25 });
    try std.testing.expect(37 == try readVarInt(&fbs));
}

//
// Recover a packet number from a truncated packet number.
//
// See: Appendix A - Sample Packet Number Decoding Algorithm
// (https://datatracker.ietf.org/doc/html/rfc9000#appendix-A.3)
//
fn decodePacketNumber(expected_pkt_num: u64, truncated_pkt_num: u64, num_bits: usize) u64 {
    assert(num_bits <= 32); // The maximum length of a encoded packet number is 32 in bits.

    const window: u64 = @as(u64, 1) << @intCast(num_bits);
    const half_window = window / 2;
    const pkt_num_mask = window - 1;

    const candidate = (expected_pkt_num & ~pkt_num_mask) | truncated_pkt_num;

    if ((candidate + half_window <= expected_pkt_num) and (candidate < (1 << 62) - window)) {
        return candidate + window;
    }

    if ((candidate > expected_pkt_num + half_window) and (candidate >= window)) {
        return candidate - window;
    }

    return candidate;
}

// Retry token roundtrip test
test "Retry token: generate and validate roundtrip" {
    var token_key: [crypto.key_len]u8 = undefined;
    sys.randomBytes(&token_key);

    const odcid = &[_]u8{ 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08 };
    const retry_scid = &[_]u8{ 0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18 };
    var addr: posix.sockaddr.storage = std.mem.zeroes(posix.sockaddr.storage);
    addr.family = posix.AF.INET;
    addr.padding[0] = 0x11; // port high byte
    addr.padding[1] = 0x51; // port low byte
    addr.padding[2] = 127;
    addr.padding[3] = 0;
    addr.padding[4] = 0;
    addr.padding[5] = 1;

    var out: [TOKEN_MAX_LEN]u8 = undefined;
    const token_len = try generateRetryToken(&out, odcid, retry_scid, addr, token_key);
    try std.testing.expect(token_len > TOKEN_NONCE_LEN + TOKEN_TAG_LEN);

    const validated = try validateRetryToken(out[0..token_len], retry_scid, addr, token_key);
    try std.testing.expect(validated != null);
    const v = validated.?;
    try std.testing.expectEqualSlices(u8, odcid, v.getOdcid());
    try std.testing.expectEqualSlices(u8, retry_scid, v.getRetryScid());
}

// Retry token: wrong address should fail
test "Retry token: wrong address rejected" {
    var token_key: [crypto.key_len]u8 = undefined;
    sys.randomBytes(&token_key);

    const odcid = &[_]u8{ 0x01, 0x02, 0x03, 0x04 };
    const retry_scid = &[_]u8{ 0x11, 0x12, 0x13, 0x14 };
    var addr1: posix.sockaddr.storage = std.mem.zeroes(posix.sockaddr.storage);
    addr1.family = posix.AF.INET;
    addr1.padding[2] = 127;
    addr1.padding[5] = 1;

    var out: [TOKEN_MAX_LEN]u8 = undefined;
    const token_len = try generateRetryToken(&out, odcid, retry_scid, addr1, token_key);

    // Different address
    var addr2 = addr1;
    addr2.padding[2] = 10;
    const validated = try validateRetryToken(out[0..token_len], retry_scid, addr2, token_key);
    try std.testing.expect(validated == null);
}

test "Retry token: good only on an Initial to the SCID its Retry gave" {
    const token_key: [crypto.key_len]u8 = @splat(5);
    const retry_scid = &[_]u8{ 0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18 };
    const addr = std.mem.zeroes(posix.sockaddr.storage);
    var out: [TOKEN_MAX_LEN]u8 = undefined;
    const token_len = try generateRetryToken(&out, &.{ 1, 2, 3, 4, 5, 6, 7, 8 }, retry_scid, addr, token_key);

    try std.testing.expect(try validateRetryToken(out[0..token_len], retry_scid, addr, token_key) != null);
    try std.testing.expect(try validateRetryToken(out[0..token_len], &.{ 0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x19 }, addr, token_key) == null);
    try std.testing.expect(try validateRetryToken(out[0..token_len], retry_scid[0..7], addr, token_key) == null);
}

// Retry token: wrong key should fail
test "Retry token: wrong key rejected" {
    var token_key: [crypto.key_len]u8 = undefined;
    sys.randomBytes(&token_key);

    const odcid = &[_]u8{ 0x01, 0x02, 0x03, 0x04 };
    const retry_scid = &[_]u8{ 0x11, 0x12, 0x13, 0x14 };
    var addr: posix.sockaddr.storage = std.mem.zeroes(posix.sockaddr.storage);
    addr.family = posix.AF.INET;

    var out: [TOKEN_MAX_LEN]u8 = undefined;
    const token_len = try generateRetryToken(&out, odcid, retry_scid, addr, token_key);

    // Different key
    var wrong_key: [crypto.key_len]u8 = undefined;
    sys.randomBytes(&wrong_key);
    const validated = try validateRetryToken(out[0..token_len], retry_scid, addr, wrong_key);
    try std.testing.expect(validated == null);
}

// Retry token: a peer-chosen length past our own tokens' is rejected
test "Retry token: oversized token rejected" {
    var token_key: [crypto.key_len]u8 = undefined;
    sys.randomBytes(&token_key);
    const addr: posix.sockaddr.storage = std.mem.zeroes(posix.sockaddr.storage);

    var token: [200]u8 = undefined;
    sys.randomBytes(&token);
    try std.testing.expect(try validateRetryToken(&token, &.{}, addr, token_key) == null);
}

fn testIn6(ip: [16]u8, port: u16) posix.sockaddr.storage {
    var in6: posix.sockaddr.in6 = std.mem.zeroes(posix.sockaddr.in6);
    in6.family = posix.AF.INET6;
    in6.port = std.mem.nativeToBig(u16, port);
    in6.addr = ip;
    var storage = std.mem.zeroes(posix.sockaddr.storage);
    @memcpy(std.mem.asBytes(&storage)[0..@sizeOf(posix.sockaddr.in6)], std.mem.asBytes(&in6));
    return storage;
}

fn testIn4(ip: [4]u8, port: u16) posix.sockaddr.storage {
    var in4: posix.sockaddr.in = std.mem.zeroes(posix.sockaddr.in);
    in4.family = posix.AF.INET;
    in4.port = std.mem.nativeToBig(u16, port);
    in4.addr = @bitCast(ip);
    var storage = std.mem.zeroes(posix.sockaddr.storage);
    @memcpy(std.mem.asBytes(&storage)[0..@sizeOf(posix.sockaddr.in)], std.mem.asBytes(&in4));
    return storage;
}

test "Retry tokens bind the whole client address, NEW_TOKEN tokens its IP; IPv4 on a dual-stack socket included" {
    const key: [crypto.key_len]u8 = @splat(3);
    const v4 = @as([10]u8, @splat(0)) ++ [_]u8{ 0xff, 0xff };
    const v6 = [_]u8{ 0x20, 0x01, 0x0d, 0xb8, 0, 0, 0, 1 } ++ @as([7]u8, @splat(0));
    // An address, another IP, the same IP from another port.
    const sets = [_][3]posix.sockaddr.storage{
        .{ testIn6(v4 ++ [_]u8{ 198, 51, 100, 7 }, 4433), testIn6(v4 ++ [_]u8{ 203, 0, 113, 9 }, 4433), testIn6(v4 ++ [_]u8{ 198, 51, 100, 7 }, 50123) },
        .{ testIn6(v6 ++ [_]u8{1}, 4433), testIn6(v6 ++ [_]u8{2}, 4433), testIn6(v6 ++ [_]u8{1}, 50123) },
        .{ testIn4(.{ 198, 51, 100, 7 }, 4433), testIn4(.{ 203, 0, 113, 9 }, 4433), testIn4(.{ 198, 51, 100, 7 }, 50123) },
    };
    for (sets) |set| {
        var out: [TOKEN_MAX_LEN]u8 = undefined;
        const retry_len = try generateRetryToken(&out, &.{ 1, 2, 3, 4, 5, 6, 7, 8 }, &.{ 9, 9, 9, 9 }, set[0], key);
        try std.testing.expect(try validateRetryToken(out[0..retry_len], &.{ 9, 9, 9, 9 }, set[0], key) != null);
        try std.testing.expect(try validateRetryToken(out[0..retry_len], &.{ 9, 9, 9, 9 }, set[1], key) == null);
        try std.testing.expect(try validateRetryToken(out[0..retry_len], &.{ 9, 9, 9, 9 }, set[2], key) == null);

        const new_len = try generateNewToken(&out, set[0], key);
        try std.testing.expect(validateNewToken(out[0..new_len], set[0], key));
        try std.testing.expect(!validateNewToken(out[0..new_len], set[1], key));
        try std.testing.expect(validateNewToken(out[0..new_len], set[2], key));
    }
}

test "a token sealed under our key but not as a Retry token is rejected, whatever it holds" {
    const key: [crypto.key_len]u8 = @splat(3);
    const addr = testIn6(@splat(0), 4433);
    // No CIDs, then a timestamp no clock gives: what a NEW_TOKEN's bytes
    // look like when read with the Retry layout.
    var plaintext: [2 + 8 + ADDR_BINDING_LEN]u8 = undefined;
    plaintext[0..2].* = .{ 0, 0 };
    std.mem.writeInt(i64, plaintext[2..10], std.math.minInt(i64), ENDIAN);
    plaintext[10..].* = addrBinding(&addr);

    var token: [TOKEN_NONCE_LEN + plaintext.len + TOKEN_TAG_LEN]u8 = undefined;
    token[0..TOKEN_NONCE_LEN].* = @splat(7);
    crypto.Aead.encrypt(token[TOKEN_NONCE_LEN..][0..plaintext.len], token[TOKEN_NONCE_LEN + plaintext.len ..][0..TOKEN_TAG_LEN], &plaintext, "", token[0..TOKEN_NONCE_LEN].*, key);
    try std.testing.expect(try validateRetryToken(&token, &.{}, addr, key) == null);

    var new_token: [TOKEN_MAX_LEN]u8 = undefined;
    const n = try generateNewToken(&new_token, addr, key);
    try std.testing.expect(try validateRetryToken(new_token[0..n], &.{}, addr, key) == null);
}

test "a Version Negotiation packet's remainder is its version list" {
    // Routing sizes every packet from remainder_len, this one included.
    var bytes = [_]u8{ 0xc0, 0, 0, 0, 0, 4, 1, 2, 3, 4, 2, 5, 6, 0, 0, 0, 1, 0x6b, 0x33, 0x43, 0xcf };
    var fbs = io.fixedBufferStream(bytes[0..]);
    const header = try Header.parse(&fbs, 0);
    try std.testing.expectEqual(PacketType.version_negotiation, header.packet_type);
    try std.testing.expectEqual(@as(usize, 8), header.remainder_len);
    try std.testing.expectEqual(bytes.len, fbs.seek + header.remainder_len);
}

// Retry integrity tag verification
test "Retry: integrity tag compute and verify" {
    const odcid = &[_]u8{ 0x83, 0x94, 0xc8, 0xf0, 0x3e, 0x51, 0x57, 0x08 };

    // Build a minimal Retry-like packet (header only, no tag yet)
    var pkt_buf: [128]u8 = undefined;
    var pkt_fbs = io.fixedBufferStream(&pkt_buf);
    const pkt_writer = &pkt_fbs;

    // First byte: Retry packet type
    try pkt_writer.writeByte(@backingInt(PacketType.retry));
    // Version
    try pkt_writer.writeInt(u32, 0x00000001, ENDIAN);
    // DCID
    try pkt_writer.writeByte(4);
    try pkt_writer.writeAll(&[_]u8{ 0x01, 0x02, 0x03, 0x04 });
    // SCID
    try pkt_writer.writeByte(4);
    try pkt_writer.writeAll(&[_]u8{ 0x05, 0x06, 0x07, 0x08 });
    // Token
    try pkt_writer.writeAll("some_token_data");

    const pkt_without_tag = pkt_fbs.buffered();

    // Compute tag
    const tag = try computeRetryIntegrityTag(pkt_without_tag, odcid, 0x00000001);

    // Build full packet with tag
    var full_pkt: [256]u8 = undefined;
    @memcpy(full_pkt[0..pkt_without_tag.len], pkt_without_tag);
    @memcpy(full_pkt[pkt_without_tag.len..][0..RETRY_INTEGRITY_TAG_SIZE], &tag);
    const full_len = pkt_without_tag.len + RETRY_INTEGRITY_TAG_SIZE;

    // Verify
    const valid = try verifyRetryIntegrity(full_pkt[0..full_len], odcid, 0x00000001);
    try std.testing.expect(valid);

    // Tamper with packet and verify fails
    full_pkt[10] ^= 0xFF;
    const invalid = try verifyRetryIntegrity(full_pkt[0..full_len], odcid, 0x00000001);
    try std.testing.expect(!invalid);
}

// Header parsing tests

test "Header.parse: Initial packet" {
    // Build a minimal Initial packet header
    var buf: [64]u8 = undefined;
    var pos: usize = 0;
    // First byte: long header (0x80) | Initial (0x00) | fixed bit (0x40) | PN len 0 (0x00)
    buf[pos] = 0xC0;
    pos += 1;
    // Version: QUIC v1
    std.mem.writeInt(u32, buf[pos..][0..4], protocol.QUIC_V1, .big);
    pos += 4;
    // DCID length + DCID
    buf[pos] = 8;
    pos += 1;
    @memset(buf[pos..][0..8], 0xAA);
    pos += 8;
    // SCID length + SCID
    buf[pos] = 4;
    pos += 1;
    @memset(buf[pos..][0..4], 0xBB);
    pos += 4;
    // Token length (varint 0)
    buf[pos] = 0;
    pos += 1;
    // Payload length (varint: 2-byte encoding of 20)
    buf[pos] = 0x40;
    buf[pos + 1] = 20;
    pos += 2;
    // PN (1 byte, will be masked by header protection in practice)
    buf[pos] = 0x00;
    pos += 1;
    // Payload (19 bytes to fill the declared length - 1 PN byte)
    @memset(buf[pos..][0..19], 0x00);
    pos += 19;

    var fbs = io.fixedBufferStream(buf[0..pos]);
    const header = try Header.parse(&fbs, 8);
    try std.testing.expectEqual(PacketType.initial, header.packet_type);
    try std.testing.expectEqual(protocol.QUIC_V1, header.version);
    try std.testing.expectEqual(@as(usize, 8), header.dcid.len);
    try std.testing.expectEqual(@as(usize, 4), header.scid.len);
    // Token is present but empty (zero-length)
    if (header.token) |tok| {
        try std.testing.expectEqual(@as(usize, 0), tok.len);
    }
}

test "Header.parse: Short header (1-RTT)" {
    var buf: [32]u8 = undefined;
    // First byte: short header (0x00) | fixed bit (0x40) | PN len 0 (0x00)
    buf[0] = 0x40;
    // DCID (8 bytes)
    @memset(buf[1..9], 0xCC);
    // PN (1 byte) + payload
    buf[9] = 0x01;
    @memset(buf[10..20], 0x00);

    var fbs = io.fixedBufferStream(buf[0..20]);
    const header = try Header.parse(&fbs, 8);
    try std.testing.expectEqual(PacketType.one_rtt, header.packet_type);
    try std.testing.expectEqual(@as(usize, 8), header.dcid.len);
}

test "Header.parse rejects a long header with the fixed bit clear" {
    // 0x80: long header form, fixed bit clear (RFC 9000 17.2).
    var buf = [_]u8{ 0x80, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00 };
    var fbs = io.fixedBufferStream(&buf);
    try std.testing.expectError(error.InvalidPacket, Header.parse(&fbs, 8));
}

test "splitProtected rejects lengths the datagram cannot back" {
    var buf = @as([64]u8, @splat(0));
    var fbs = io.fixedBufferStream(&buf);
    fbs.seek = 10;

    var header = Header{ .packet_start = 0, .packet_number_len = 4, .remainder_len = 14 };
    var ad: [MAX_PACKET_LEN]u8 = undefined;

    const ok = try splitProtected(&header, &fbs, 0xc0, &ad);
    try std.testing.expectEqual(@as(usize, 10), ok.ad.len);
    try std.testing.expectEqual(@as(usize, 10), ok.payload.len);
    try std.testing.expectEqual(@as(u8, 0xc0), ok.ad[0]);

    // Below the packet number length the subtraction underflows.
    header.remainder_len = 2;
    try std.testing.expectError(error.InvalidPacket, splitProtected(&header, &fbs, 0xc0, &ad));

    // Above what is left of the datagram it reads past the end.
    header.remainder_len = 4 + 100;
    try std.testing.expectError(error.InvalidPacket, splitProtected(&header, &fbs, 0xc0, &ad));

    // A header longer than the buffer the associated data is built in — an
    // Initial's token is the peer's to size.
    header.remainder_len = 14;
    var small: [4]u8 = undefined;
    try std.testing.expectError(error.InvalidPacket, splitProtected(&header, &fbs, 0xc0, &small));
}

test "decodePacketNumber: RFC 9000 Appendix A examples" {
    // Example from RFC 9000 Appendix A:
    // largest_pn = 0xa82f30ea, truncated_pn = 0x9b32, pn_nbits = 16
    // Expected: 0xa82f9b32
    try std.testing.expectEqual(@as(u64, 0xa82f9b32), decodePacketNumber(0xa82f30ea, 0x9b32, 16));

    // Simple case: no wraparound
    try std.testing.expectEqual(@as(u64, 5), decodePacketNumber(4, 5, 8));

    // Wraparound case: truncated 0x00, largest 0xfe, 8 bits
    // Half = 128. candidate = (0xfe & ~0xff) | 0x00 = 0xfe00? No...
    // Let's use the simplest case: largest=0, truncated=0, nbits=8 -> 0
    try std.testing.expectEqual(@as(u64, 0), decodePacketNumber(0, 0, 8));
}
