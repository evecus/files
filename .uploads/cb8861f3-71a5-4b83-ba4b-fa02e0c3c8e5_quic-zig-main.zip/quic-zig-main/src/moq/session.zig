// MoQ Transport session state machine, draft-17.
//
// §3.3: each side opens its own unidirectional control stream and puts a
// SETUP on it; every request then gets its own bidirectional stream, whose
// first message identifies the request and whose responses come back on the
// same stream. There are no request IDs on the wire — the stream *is* the
// identifier.
//
// Generic over the transport so raw QUIC and WebTransport share one
// implementation. The transport must provide:
//
//     openUni() !u64
//     openBidi() !u64
//     write(stream_id: u64, data: []const u8) !void
//     finish(stream_id: u64) void          // FIN the send side
//     reset(stream_id: u64, code: u64) void // RESET_STREAM
//     stopSending(stream_id: u64, code: u64) void // STOP_SENDING
//
// Buffering: a control message can arrive split across reads, and a peer
// may coalesce several into one. Bytes are accumulated per stream and every
// complete envelope is drained before returning.
//
// This is the control plane only. A subgroup stream's header is not an
// envelope and will never parse as one, so the caller classifies data
// streams itself and does not feed them here — a stream that fills its
// buffer without producing a message is reported as a protocol violation
// rather than accumulating forever.

const std = @import("std");
const testing = std.testing;

const io = @import("../io_compat.zig");
const wire = @import("wire.zig");
const msg = @import("message.zig");
const codes = @import("message_codes.zig");
const track = @import("track.zig");
const version = @import("version.zig");

pub const MAX_STREAMS: usize = 32;
/// Events one read produces at most; each gets its own namespace buffer.
pub const MAX_EVENTS: usize = 16;
pub const STREAM_BUF_SIZE: usize = 16 * 1024;

const NO_STREAM: u64 = std.math.maxInt(u64);

pub const Error = error{
    TooManyStreams,
    NotConnected,
    /// A stream filled its buffer without yielding a control message.
    StreamStalled,
} || msg.Error;

/// §3.3.3 stream reset codes. draft-18 generalises these to every request
/// stream; draft-17 already uses CANCELLED for a withdrawn request.
pub const ResetCode = struct {
    pub const INTERNAL_ERROR: u64 = 0x0;
    pub const CANCELLED: u64 = 0x1;
};

pub const StreamKind = enum {
    /// Our outbound control stream (SETUP out).
    control_out,
    /// The peer's control stream (SETUP in).
    control_in,
    /// A bidirectional request stream, ours or the peer's.
    request,
};

/// What the peer did, surfaced to the caller one event at a time.
pub const Event = union(enum) {
    peer_setup: struct { stream_id: u64, options: msg.SetupOptions },
    request_ok: struct { stream_id: u64 },
    request_error: struct { stream_id: u64, err: msg.RequestError },
    /// A peer asking us to serve a track. A relay sends this to whoever
    /// published the namespace, which is how a subscription is routed.
    subscribe: struct { stream_id: u64, subscribe: msg.Subscribe },
    subscribe_ok: struct { stream_id: u64, ok: msg.SubscribeOk },
    publish: struct { stream_id: u64, publish: msg.Publish },
    namespace: struct { stream_id: u64, namespace: msg.Namespace },
    namespace_done: struct { stream_id: u64, namespace: msg.Namespace },
    goaway: struct { stream_id: u64, goaway: msg.Goaway },
    publish_done: struct { stream_id: u64, done: msg.PublishDone },
    /// A message we decode but have no specific event for, and anything on
    /// a data stream. Carries the raw envelope so the caller can decide.
    other: struct { stream_id: u64, type: u64, payload: []const u8 },
    /// Peer closed the stream.
    stream_finished: struct { stream_id: u64 },
};

const StreamState = struct {
    id: u64 = NO_STREAM,
    /// Until a message arrives, a stream is assumed to be a request — a
    /// SETUP reclassifies it as the peer's control stream.
    kind: StreamKind = .request,
    buf: [STREAM_BUF_SIZE]u8 = undefined,
    len: usize = 0,
    /// Bytes already turned into events. Dropped at the start of the next
    /// `onStreamData`, not at once: those events still point into `buf`.
    parsed: usize = 0,
    /// FIN seen; the slot is freed on the next call, for the same reason.
    release_pending: bool = false,

    fn append(self: *StreamState, bytes: []const u8) void {
        const n = @min(bytes.len, self.buf.len - self.len);
        @memcpy(self.buf[self.len..][0..n], bytes[0..n]);
        self.len += n;
    }

    fn consume(self: *StreamState, n: usize) void {
        @memmove(self.buf[0 .. self.len - n], self.buf[n..self.len]);
        self.len -= n;
    }
};

pub fn Session(comptime Transport: type) type {
    return struct {
        const Self = @This();

        transport: Transport,
        draft: version.Draft = version.DEFAULT,
        implementation: []const u8 = "quic-zig/moq",
        /// §9.3.1 PATH and AUTHORITY: only for raw QUIC, where no request
        /// URI carries them. Over WebTransport the CONNECT already did.
        path: ?[]const u8 = null,
        authority: ?[]const u8 = null,

        control_out: ?u64 = null,
        control_in: ?u64 = null,
        setup_sent: bool = false,
        setup_received: bool = false,

        streams: [MAX_STREAMS]StreamState = @splat(.{}),

        // Namespace tuples decoded out of incoming messages alias these, one
        // per event of a read, so they outlive the call that decoded them.
        ns_bufs: [MAX_EVENTS]msg.NamespaceBuf = undefined,
        kv_buf: [16]wire.KvEntry = undefined,

        pub fn init(transport: Transport) Self {
            return .{ .transport = transport };
        }

        // --- streams -------------------------------------------------

        fn slot(self: *Self, id: u64) ?*StreamState {
            for (&self.streams) |*s| if (s.id == id) return s;
            return null;
        }

        fn claim(self: *Self, id: u64, kind: StreamKind) ?*StreamState {
            if (self.slot(id)) |s| return s;
            for (&self.streams) |*s| if (s.id == NO_STREAM) {
                s.* = .{ .id = id, .kind = kind };
                return s;
            };
            return null;
        }

        /// Frees the slot at the next call: this read's events still point
        /// into its buffer.
        fn release(self: *Self, id: u64) void {
            if (self.slot(id)) |s| s.release_pending = true;
        }

        pub fn kindOf(self: *Self, id: u64) ?StreamKind {
            if (self.slot(id)) |s| if (!s.release_pending) return s.kind;
            return null;
        }

        // --- sending -------------------------------------------------

        /// Opens our control stream and puts SETUP on it. §3.3 lets both
        /// sides do this immediately; neither waits for the other.
        pub fn sendSetup(self: *Self) !void {
            const sid = try self.transport.openUni();
            _ = self.claim(sid, .control_out) orelse return Error.TooManyStreams;
            self.control_out = sid;

            var buf: [512]u8 = undefined;
            var fbs = io.fixedBufferStream(&buf);
            try msg.writeSetup(&fbs, .{
                .implementation = self.implementation,
                .path = self.path,
                .authority = self.authority,
            });
            try self.transport.write(sid, buf[0..fbs.seek]);
            self.setup_sent = true;
        }

        /// Opens a request stream and writes `payload` (a complete encoded
        /// control message) as its first message. Returns the stream id,
        /// which is how the caller correlates the response.
        pub fn sendRequest(self: *Self, payload: []const u8) !u64 {
            const sid = try self.transport.openBidi();
            _ = self.claim(sid, .request) orelse return Error.TooManyStreams;
            try self.transport.write(sid, payload);
            return sid;
        }

        /// Withdraws a request by terminating both directions of its stream
        /// (draft-18 §3.3.2). draft-18 makes this the way a namespace is
        /// un-published; draft-17 already allows it.
        pub fn cancelRequest(self: *Self, stream_id: u64, code: u64) void {
            self.transport.reset(stream_id, code);
            self.transport.stopSending(stream_id, code);
            self.release(stream_id);
        }

        pub fn finishStream(self: *Self, stream_id: u64) void {
            self.transport.finish(stream_id);
        }

        // --- receiving -----------------------------------------------

        /// Feeds one read into the session. `out` receives the events it
        /// produced; the return value says how many. Events borrow from
        /// the stream's buffer and from `self`, so consume them before the
        /// next call.
        pub fn onStreamData(
            self: *Self,
            stream_id: u64,
            data: []const u8,
            fin: bool,
            out: []Event,
        ) !usize {
            var n: usize = 0;
            self.settle();

            if (data.len > 0) {
                const s = self.claim(stream_id, .request) orelse return Error.TooManyStreams;
                s.append(data);

                // A full buffer with nothing parsable is not going to
                // improve by waiting for more bytes.
                if (s.len == s.buf.len) return Error.StreamStalled;

                while (n < @min(out.len, MAX_EVENTS)) {
                    const parsed = msg.parseEnvelope(s.buf[s.parsed..s.len]) catch break;
                    s.parsed += parsed.consumed;
                    const ev = self.classify(stream_id, s, parsed.env, &self.ns_bufs[n]) catch continue;
                    if (ev) |e| {
                        out[n] = e;
                        n += 1;
                    }
                }
            }

            if (fin) {
                if (n < out.len) {
                    out[n] = .{ .stream_finished = .{ .stream_id = stream_id } };
                    n += 1;
                }
                if (self.slot(stream_id)) |s| s.release_pending = true;
            }
            return n;
        }

        /// Frees what the previous call's events were still borrowing.
        fn settle(self: *Self) void {
            for (&self.streams) |*s| {
                if (s.id == NO_STREAM) continue;
                if (s.release_pending) {
                    s.* = .{};
                } else if (s.parsed > 0) {
                    s.consume(s.parsed);
                    s.parsed = 0;
                }
            }
        }

        fn classify(self: *Self, stream_id: u64, s: *StreamState, env: msg.Envelope, ns_buf: *msg.NamespaceBuf) !?Event {
            // A SETUP arriving on a stream we have not classified marks it
            // as the peer's control stream.
            if (env.type == codes.MSG_SETUP) {
                s.kind = .control_in;
                self.control_in = stream_id;
                self.setup_received = true;
                return .{ .peer_setup = .{
                    .stream_id = stream_id,
                    .options = try msg.decodeSetupPayload(env.payload),
                } };
            }

            return switch (env.type) {
                codes.MSG_REQUEST_OK => Event{ .request_ok = .{ .stream_id = stream_id } },
                codes.MSG_REQUEST_ERROR => Event{ .request_error = .{
                    .stream_id = stream_id,
                    .err = try msg.decodeRequestError(env.payload),
                } },
                codes.MSG_SUBSCRIBE => Event{ .subscribe = .{
                    .stream_id = stream_id,
                    .subscribe = try msg.decodeSubscribe(env.payload, ns_buf, self.draft),
                } },
                codes.MSG_SUBSCRIBE_OK => Event{ .subscribe_ok = .{
                    .stream_id = stream_id,
                    .ok = try msg.decodeSubscribeOk(env.payload, self.draft),
                } },
                codes.MSG_PUBLISH => Event{ .publish = .{
                    .stream_id = stream_id,
                    .publish = try msg.decodePublish(env.payload, ns_buf, self.draft),
                } },
                codes.MSG_NAMESPACE => Event{ .namespace = .{
                    .stream_id = stream_id,
                    .namespace = try msg.decodeNamespace(env.payload, ns_buf),
                } },
                codes.MSG_NAMESPACE_DONE => Event{ .namespace_done = .{
                    .stream_id = stream_id,
                    .namespace = try msg.decodeNamespaceDone(env.payload, ns_buf),
                } },
                codes.MSG_GOAWAY => Event{ .goaway = .{
                    .stream_id = stream_id,
                    .goaway = try msg.decodeGoaway(env.payload),
                } },
                codes.MSG_PUBLISH_DONE => Event{ .publish_done = .{
                    .stream_id = stream_id,
                    .done = try msg.decodePublishDone(env.payload),
                } },
                else => Event{ .other = .{
                    .stream_id = stream_id,
                    .type = env.type,
                    .payload = env.payload,
                } },
            };
        }

        pub fn isEstablished(self: *const Self) bool {
            return self.setup_sent and self.setup_received;
        }
    };
}

// --- tests ---------------------------------------------------------------

/// Records what a session wrote, and hands back stream ids the way a real
/// transport would.
const FakeTransport = struct {
    next_uni: u64 = 2,
    next_bidi: u64 = 0,
    written: [8192]u8 = undefined,
    written_len: usize = 0,
    last_reset: ?struct { id: u64, code: u64 } = null,
    last_stop_sending: ?struct { id: u64, code: u64 } = null,
    finished: [16]u64 = undefined,
    finished_len: usize = 0,

    fn openUni(self: *FakeTransport) !u64 {
        defer self.next_uni += 4;
        return self.next_uni;
    }
    fn openBidi(self: *FakeTransport) !u64 {
        defer self.next_bidi += 4;
        return self.next_bidi;
    }
    fn write(self: *FakeTransport, _: u64, data: []const u8) !void {
        @memcpy(self.written[self.written_len..][0..data.len], data);
        self.written_len += data.len;
    }
    fn finish(self: *FakeTransport, id: u64) void {
        self.finished[self.finished_len] = id;
        self.finished_len += 1;
    }
    fn reset(self: *FakeTransport, id: u64, code: u64) void {
        self.last_reset = .{ .id = id, .code = code };
    }
    fn stopSending(self: *FakeTransport, id: u64, code: u64) void {
        self.last_stop_sending = .{ .id = id, .code = code };
    }
};

const TestSession = Session(*FakeTransport);

test "SETUP goes out on a uni control stream" {
    var t = FakeTransport{};
    var s = TestSession.init(&t);
    try s.sendSetup();

    try testing.expect(s.setup_sent);
    try testing.expectEqual(@as(?u64, 2), s.control_out);
    try testing.expectEqual(StreamKind.control_out, s.kindOf(2).?);

    const parsed = try msg.parseEnvelope(t.written[0..t.written_len]);
    try testing.expectEqual(codes.MSG_SETUP, parsed.env.type);
    const opts = try msg.decodeSetupPayload(parsed.env.payload);
    try testing.expectEqualStrings("quic-zig/moq", opts.implementation.?);
    try testing.expectEqual(@as(?[]const u8, null), opts.path);
}

test "raw-QUIC SETUP carries PATH and AUTHORITY" {
    var t = FakeTransport{};
    var s = TestSession.init(&t);
    s.path = "/anon";
    s.authority = "cdn.moq.dev:443";
    try s.sendSetup();

    const parsed = try msg.parseEnvelope(t.written[0..t.written_len]);
    const opts = try msg.decodeSetupPayload(parsed.env.payload);
    try testing.expectEqualStrings("/anon", opts.path.?);
    try testing.expectEqualStrings("cdn.moq.dev:443", opts.authority.?);
}

test "peer SETUP completes the handshake" {
    var t = FakeTransport{};
    var s = TestSession.init(&t);
    try s.sendSetup();
    try testing.expect(!s.isEstablished());

    var buf: [256]u8 = undefined;
    var fbs = io.fixedBufferStream(&buf);
    try msg.writeSetup(&fbs, .{ .implementation = "peer/1" });

    var events: [4]Event = undefined;
    const n = try s.onStreamData(3, buf[0..fbs.seek], false, &events);
    try testing.expectEqual(@as(usize, 1), n);
    try testing.expectEqualStrings("peer/1", events[0].peer_setup.options.implementation.?);
    try testing.expect(s.isEstablished());
    try testing.expectEqual(@as(?u64, 3), s.control_in);
    try testing.expectEqual(StreamKind.control_in, s.kindOf(3).?);
}

test "a message split across reads is reassembled" {
    var t = FakeTransport{};
    var s = TestSession.init(&t);

    var buf: [256]u8 = undefined;
    var fbs = io.fixedBufferStream(&buf);
    try msg.writeRequestError(&fbs, .{ .error_code = codes.ERR_UNAUTHORIZED, .reason = "nope" });
    const encoded = buf[0..fbs.seek];

    var events: [4]Event = undefined;
    // Nothing complete yet.
    try testing.expectEqual(@as(usize, 0), try s.onStreamData(0, encoded[0 .. encoded.len - 3], false, &events));
    const n = try s.onStreamData(0, encoded[encoded.len - 3 ..], false, &events);
    try testing.expectEqual(@as(usize, 1), n);
    try testing.expectEqual(codes.ERR_UNAUTHORIZED, events[0].request_error.err.error_code);
    try testing.expectEqualStrings("nope", events[0].request_error.err.reason);
}

test "an event's strings survive the messages and FIN read with it" {
    var t = FakeTransport{};
    var s = TestSession.init(&t);

    // imquic sends REQUEST_ERROR and FIN together; compacting the buffer
    // after each message left the reason pointing at what came next.
    var buf: [512]u8 = undefined;
    var fbs = io.fixedBufferStream(&buf);
    try msg.writeRequestError(&fbs, .{ .error_code = 0, .reason = "Namespace already published" });
    try msg.writeGoaway(&fbs, .{ .new_uri = "https://elsewhere/moq" });

    var events: [8]Event = undefined;
    const n = try s.onStreamData(0, buf[0..fbs.seek], true, &events);
    try testing.expectEqual(@as(usize, 3), n);
    try testing.expectEqualStrings("Namespace already published", events[0].request_error.err.reason);
    try testing.expectEqualStrings("https://elsewhere/moq", events[1].goaway.goaway.new_uri);
    try testing.expectEqual(@as(u64, 0), events[2].stream_finished.stream_id);

    // The next call frees the finished stream's slot.
    _ = try s.onStreamData(4, &.{}, false, &events);
    try testing.expectEqual(@as(?StreamKind, null), s.kindOf(0));
}

test "coalesced messages all come out of one read" {
    var t = FakeTransport{};
    var s = TestSession.init(&t);

    var buf: [512]u8 = undefined;
    var fbs = io.fixedBufferStream(&buf);
    try msg.writeRequestOk(&fbs, .{});
    try msg.writeSubscribeOk(&fbs, .{ .track_alias = 7 });
    try msg.writeGoaway(&fbs, .{ .new_uri = "https://elsewhere/moq" });

    var events: [8]Event = undefined;
    const n = try s.onStreamData(0, buf[0..fbs.seek], false, &events);
    try testing.expectEqual(@as(usize, 3), n);
    try testing.expectEqual(@as(u64, 0), events[0].request_ok.stream_id);
    try testing.expectEqual(@as(u64, 7), events[1].subscribe_ok.ok.track_alias);
    try testing.expectEqualStrings("https://elsewhere/moq", events[2].goaway.goaway.new_uri);
}

test "a request opens a bidi stream and FIN releases it" {
    var t = FakeTransport{};
    var s = TestSession.init(&t);

    var buf: [256]u8 = undefined;
    var fbs = io.fixedBufferStream(&buf);
    const ns = [_][]const u8{ "moq-test", "interop" };
    try msg.writePublishNamespace(&fbs, .{ .track_namespace = &ns }, .draft_17);

    const sid = try s.sendRequest(buf[0..fbs.seek]);
    try testing.expectEqual(@as(u64, 0), sid);
    try testing.expectEqual(StreamKind.request, s.kindOf(sid).?);

    var events: [4]Event = undefined;
    const n = try s.onStreamData(sid, &.{}, true, &events);
    try testing.expectEqual(@as(usize, 1), n);
    try testing.expectEqual(sid, events[0].stream_finished.stream_id);
    try testing.expectEqual(@as(?StreamKind, null), s.kindOf(sid));
}

test "cancelling a request terminates both directions of its stream" {
    var t = FakeTransport{};
    var s = TestSession.init(&t);
    const sid = try s.sendRequest(&.{});
    s.cancelRequest(sid, ResetCode.CANCELLED);
    try testing.expectEqual(sid, t.last_reset.?.id);
    try testing.expectEqual(ResetCode.CANCELLED, t.last_reset.?.code);
    try testing.expectEqual(sid, t.last_stop_sending.?.id);
    try testing.expectEqual(@as(?StreamKind, null), s.kindOf(sid));
}

test "an undecodable message is skipped, not fatal" {
    var t = FakeTransport{};
    var s = TestSession.init(&t);

    // A REQUEST_ERROR whose body is too short to decode, then a good one.
    var buf: [256]u8 = undefined;
    var fbs = io.fixedBufferStream(&buf);
    try msg.writeEnvelope(&fbs, codes.MSG_REQUEST_ERROR, &.{});
    try msg.writeRequestOk(&fbs, .{});

    var events: [4]Event = undefined;
    const n = try s.onStreamData(0, buf[0..fbs.seek], false, &events);
    try testing.expectEqual(@as(usize, 1), n);
    try testing.expectEqual(@as(u64, 0), events[0].request_ok.stream_id);
}

test "namespaces decoded from an event outlive the call" {
    var t = FakeTransport{};
    var s = TestSession.init(&t);

    var buf: [256]u8 = undefined;
    var fbs = io.fixedBufferStream(&buf);
    const ns = [_][]const u8{ "moq-test", "interop" };
    try msg.writeNamespace(&fbs, .{ .track_namespace_suffix = &ns });

    var events: [4]Event = undefined;
    _ = try s.onStreamData(0, buf[0..fbs.seek], false, &events);
    const got = events[0].namespace.namespace.track_namespace_suffix;
    try testing.expectEqual(@as(usize, 2), got.len);
    try testing.expectEqualStrings("moq-test", got[0]);
    try testing.expectEqualStrings("interop", got[1]);
}

test "coalesced namespaces each keep their own, even past a cancel" {
    // All of a read's namespaces shared one buffer, and cancelling a request
    // from an event handler wiped the stream the rest were read from.
    var t = FakeTransport{};
    var s = TestSession.init(&t);
    const sid = try s.sendRequest("");

    var buf: [256]u8 = undefined;
    var fbs = io.fixedBufferStream(&buf);
    try msg.writeNamespace(&fbs, .{ .track_namespace_suffix = &.{ "alice", "cam" } });
    try msg.writeNamespace(&fbs, .{ .track_namespace_suffix = &.{"bob"} });

    var events: [4]Event = undefined;
    const n = try s.onStreamData(sid, buf[0..fbs.seek], false, &events);
    try testing.expectEqual(@as(usize, 2), n);
    s.cancelRequest(sid, 0);
    const first = events[0].namespace.namespace.track_namespace_suffix;
    try testing.expectEqual(@as(usize, 2), first.len);
    try testing.expectEqualStrings("alice", first[0]);
    try testing.expectEqualStrings("cam", first[1]);
    try testing.expectEqualStrings("bob", events[1].namespace.namespace.track_namespace_suffix[0]);
}

test "a stream that never yields a message is not buffered forever" {
    var t = FakeTransport{};
    var s = TestSession.init(&t);

    // A subgroup header is not an envelope and never will be. Rather than
    // growing until the buffer is full and then silently stalling, say so.
    const junk: [512]u8 = @splat(0xff);
    var events: [4]Event = undefined;
    var pushed: usize = 0;
    while (pushed < STREAM_BUF_SIZE) : (pushed += junk.len) {
        _ = s.onStreamData(0, &junk, false, &events) catch |e| {
            try testing.expectEqual(Error.StreamStalled, e);
            return;
        };
    }
    try testing.expectError(Error.StreamStalled, s.onStreamData(0, &junk, false, &events));
}

test "stream table refuses to overflow" {
    var t = FakeTransport{};
    var s = TestSession.init(&t);
    for (0..MAX_STREAMS) |i| _ = s.claim(@intCast(i), .request).?;
    var events: [2]Event = undefined;
    try testing.expectError(Error.TooManyStreams, s.onStreamData(999, "x", false, &events));
}
