quiche cli apps:

RUST_BACKTRACE=1 RUST_LOG=debug cargo run --bin quiche-server
RUST_LOG=debug cargo run --bin quiche-client -- --method GET --connect-to 127.0.0.1:4433 --no-verify https://localhost:4433
---

- Generate Self-signed Certificate: https://www.linode.com/docs/guides/create-a-self-signed-tls-certificate/
- Getting Chrome to accept self-signed localhost certificate: https://stackoverflow.com/a/60516812/892698

# Become a Certificate Authority

## Generate private key

```
openssl genrsa -des3 -out myCA.key 2048
```

## Generate root certificate

```
openssl req -x509 -new -nodes -key myCA.key -sha256 -days 825 -out myCA.pem
```

(MacOS users: Add the CA to the SYSTEM certs)

# Create CA-signed certs

```
NAME=mydomain.example # Use your own domain name
```

## Generate a private key

```
openssl genrsa -out $NAME.key 2048
```

## Create a certificate-signing request

```
openssl req -new -key $NAME.key -out $NAME.csr
```

## Create a config file for the extensions

```
>$NAME.ext cat <<-EOF
authorityKeyIdentifier=keyid,issuer
basicConstraints=CA:FALSE
keyUsage = digitalSignature, nonRepudiation, keyEncipherment, dataEncipherment
subjectAltName = @alt_names
[alt_names]
DNS.1 = $NAME # Be sure to include the domain name here because Common Name is not so commonly honoured by itself
DNS.2 = bar.$NAME # Optionally, add additional domains (I've added a subdomain here)
IP.1 = 192.168.0.13 # Optionally, add an IP address (if the connection which you have planned requires it)
EOF
```

## Create the signed certificate

```
openssl x509 -req -in $NAME.csr -CA myCA.pem -CAkey myCA.key -CAcreateserial \
-out $NAME.crt -days 825 -sha256 -extfile $NAME.ext
```

## Create a private key for the server

```
cat $NAME.crt $NAME.csr > $NAME.pem
```
