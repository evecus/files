import 'dart:async';
import 'dart:convert';

import 'package:crypto/crypto.dart';
import 'package:simple_live_core/src/common/convert_helper.dart';
import 'package:simple_live_core/src/common/core_error.dart';
import 'package:simple_live_core/src/common/core_log.dart';
import 'package:simple_live_core/src/common/http_client.dart';
import 'package:simple_live_core/src/common/platform_identity.dart';
import 'package:simple_live_core/src/danmaku/bilibili_danmaku.dart';
import 'package:simple_live_core/src/interface/live_danmaku.dart';
import 'package:simple_live_core/src/interface/live_site.dart';
import 'package:simple_live_core/src/model/live_anchor_item.dart';
import 'package:simple_live_core/src/model/live_category.dart';
import 'package:simple_live_core/src/model/live_contribution_rank.dart';
import 'package:simple_live_core/src/model/live_message.dart';
import 'package:simple_live_core/src/model/live_play_url.dart';
import 'package:simple_live_core/src/model/live_room_item.dart';
import 'package:simple_live_core/src/model/live_search_result.dart';
import 'package:simple_live_core/src/model/live_room_detail.dart';
import 'package:simple_live_core/src/model/live_play_quality.dart';
import 'package:simple_live_core/src/model/live_category_result.dart';

class BiliBiliSite implements LiveSite {
  @override
  String id = "bilibili";

  @override
  String name = "哔哩哔哩直播";

  String cookie = "";
  int userId = 0;

  @override
  LiveDanmaku getDanmaku() => BiliBiliDanmaku();

  static const String kDefaultUserAgent = PlatformIdentity.bilibiliUserAgent;
  static const String kDefaultReferer = "https://live.bilibili.com/";

  String buvid3 = "";
  String buvid4 = "";
  String accessId = "";
  static Future<void> _playInfoRequestQueue = Future.value();
  static DateTime _lastPlayInfoRequestAt = DateTime.fromMillisecondsSinceEpoch(
    0,
  );

  Future<Map<String, String>> getHeader() async {
    if (buvid3.isEmpty) {
      var buvidInfo = await getBuvid();
      buvid3 = buvidInfo["b_3"] ?? "";
      buvid4 = buvidInfo["b_4"] ?? "";
    }
    return cookie.isEmpty
        ? {
            "user-agent": kDefaultUserAgent,
            "referer": kDefaultReferer,
            "cookie": 'buvid3=$buvid3;buvid4=$buvid4;',
          }
        : {
            "cookie": cookie.contains("buvid3")
                ? cookie
                : "$cookie;buvid3=$buvid3;buvid4=$buvid4;",
            "user-agent": kDefaultUserAgent,
            "referer": kDefaultReferer,
          };
  }

  /// 未登录请求头：仅携带 buvid3/buvid4，不携带账号 cookie。
  /// 用于登录态被弹幕接口风控时的回退请求。
  Future<Map<String, String>> getNologinHeader() async {
    if (buvid3.isEmpty) {
      var buvidInfo = await getBuvid();
      buvid3 = buvidInfo["b_3"] ?? "";
      buvid4 = buvidInfo["b_4"] ?? "";
    }
    final buvidCookie = [
      if (buvid3.isNotEmpty) "buvid3=$buvid3",
      if (buvid4.isNotEmpty) "buvid4=$buvid4",
    ].join(";");
    return {
      "user-agent": kDefaultUserAgent,
      "referer": kDefaultReferer,
      if (buvidCookie.isNotEmpty) "cookie": buvidCookie,
    };
  }

  List<String> parseDanmuHosts(Map data) {
    final hostListRaw = data["host_list"];
    if (hostListRaw is List) {
      return hostListRaw
          .map<String>((e) => e["host"].toString())
          .where((e) => e.isNotEmpty)
          .toList();
    }
    return const [];
  }

  @override
  Future<List<LiveCategory>> getCategores() async {
    List<LiveCategory> categories = [];
    var result = await HttpClient.instance.getJson(
      "https://api.live.bilibili.com/room/v1/Area/getList",
      queryParameters: {"need_entrance": 1, "parent_id": 0},
      header: await getHeader(),
    );
    for (var item in result["data"]) {
      List<LiveSubCategory> subs = [];
      for (var subItem in item["list"]) {
        var subCategory = LiveSubCategory(
          id: subItem["id"].toString(),
          name: asT<String?>(subItem["name"]) ?? "",
          parentId: asT<String?>(subItem["parent_id"]) ?? "",
          pic: "${asT<String?>(subItem["pic"]) ?? ""}@100w.png",
        );
        subs.add(subCategory);
      }
      var category = LiveCategory(
        children: subs,
        id: item["id"].toString(),
        name: asT<String?>(item["name"]) ?? "",
      );
      categories.add(category);
    }
    return categories;
  }

  @override
  Future<LiveCategoryResult> getCategoryRooms(
    LiveSubCategory category, {
    int page = 1,
  }) async {
    var result = await HttpClient.instance.getJson(
      "https://api.live.bilibili.com/room/v1/Area/getRoomList",
      queryParameters: {
        "platform": "web",
        "parent_area_id": category.parentId,
        "area_id": category.id,
        "page": page,
        "page_size": 30,
      },
      header: await getHeader(),
    );

    var data = (result["data"] as List?) ?? const [];
    var hasMore = data.length >= 30;
    var items = <LiveRoomItem>[];
    for (var item in data) {
      var cover =
          item["cover"]?.toString() ??
          item["user_cover"]?.toString() ??
          item["system_cover"]?.toString() ??
          "";
      var roomItem = LiveRoomItem(
        roomId: item["roomid"].toString(),
        title: item["title"].toString(),
        cover: cover.isEmpty ? "" : "$cover@400w.jpg",
        userName: item["uname"].toString(),
        online: int.tryParse(item["online"].toString()) ?? 0,
      );
      items.add(roomItem);
    }
    return LiveCategoryResult(hasMore: hasMore, items: items);
  }

  @override
  Future<List<LivePlayQuality>> getPlayQualites({
    required LiveRoomDetail detail,
  }) async {
    final qualities = <LivePlayQuality>[];
    var result = await _getRoomPlayInfo(
      queryParameters: {
        "room_id": detail.roomId,
        "protocol": "0,1",
        "format": "0,1,2",
        "codec": "0,1",
        "platform": "web",
      },
    );
    final playUrl = _readBilibiliPlayUrl(result, detail.roomId);
    var qualitiesMap = <int, String>{};
    for (var item in (playUrl["g_qn_desc"] as List?) ?? const []) {
      qualitiesMap[int.tryParse(item["qn"].toString()) ?? 0] = item["desc"]
          .toString();
    }

    final streams = (playUrl["stream"] as List?) ?? const [];
    final formats = streams.isEmpty
        ? const []
        : (streams.first["format"] as List?) ?? const [];
    final codecs = formats.isEmpty
        ? const []
        : (formats.first["codec"] as List?) ?? const [];
    final accepted = codecs.isEmpty
        ? const []
        : (codecs.first["accept_qn"] as List?) ?? const [];
    for (var item in accepted) {
      var qualityItem = LivePlayQuality(
        quality: qualitiesMap[item] ?? "未知清晰度",
        data: item,
      );
      qualities.add(qualityItem);
    }
    if (qualities.isEmpty) {
      CoreLog.w("B站播放信息未返回清晰度：roomId=${detail.roomId}");
      throw CoreError("B站暂时无法获取播放清晰度，请稍后重试");
    }
    return qualities;
  }

  Map _readBilibiliPlayUrl(dynamic result, String roomId) {
    try {
      final data = result is Map ? result["data"] : null;
      final playUrlInfo = data is Map ? data["playurl_info"] : null;
      final playUrl = playUrlInfo is Map ? playUrlInfo["playurl"] : null;
      if (playUrl is Map) {
        return playUrl;
      }
    } catch (_) {
      // The structured error below is more useful than a type-cast exception.
    }
    CoreLog.w(
      "B站播放信息响应结构异常：roomId=$roomId "
      "responseType=${result.runtimeType}",
    );
    throw CoreError("B站播放信息响应异常，请稍后重试");
  }

  @override
  Future<LivePlayUrl> getPlayUrls({
    required LiveRoomDetail detail,
    required LivePlayQuality quality,
  }) async {
    List<String> urls = [];
    var result = await _getRoomPlayInfo(
      queryParameters: {
        "room_id": detail.roomId,
        "protocol": "0,1",
        "format": "0,2",
        "codec": "0",
        "platform": "web",
        "qn": quality.data,
      },
    );
    var streamList = result["data"]["playurl_info"]["playurl"]["stream"];
    for (var streamItem in streamList) {
      var formatList = streamItem["format"];
      for (var formatItem in formatList) {
        var codecList = formatItem["codec"];
        for (var codecItem in codecList) {
          var urlList = codecItem["url_info"];
          var baseUrl = codecItem["base_url"].toString();
          for (var urlItem in urlList) {
            urls.add("${urlItem["host"]}$baseUrl${urlItem["extra"]}");
          }
        }
      }
    }
    // 对链接进行排序，包含mcdn的在后
    urls.sort((a, b) {
      if (a.contains("mcdn")) {
        return 1;
      } else {
        return -1;
      }
    });
    return LivePlayUrl(
      urls: urls,
      headers: {
        "referer": "https://live.bilibili.com",
        "user-agent": PlatformIdentity.bilibiliRoomUserAgent,
      },
    );
  }

  Future<dynamic> _getRoomPlayInfo({
    required Map<String, dynamic> queryParameters,
  }) async {
    const retryDelays = [
      Duration(milliseconds: 800),
      Duration(milliseconds: 1600),
    ];
    for (var attempt = 0; attempt <= retryDelays.length; attempt++) {
      try {
        return await _throttlePlayInfoRequest(
          () async => HttpClient.instance.getJson(
            "https://api.live.bilibili.com/xlive/web-room/v2/index/getRoomPlayInfo",
            queryParameters: queryParameters,
            header: await getHeader(),
          ),
        );
      } catch (e) {
        if (e is CoreError &&
            e.statusCode == 429 &&
            attempt < retryDelays.length) {
          final delay = retryDelays[attempt];
          CoreLog.w(
            "B站播放信息接口触发 429，${delay.inMilliseconds}ms 后重试："
            "roomId=${queryParameters["room_id"]} attempt=${attempt + 1}",
          );
          await Future.delayed(delay);
          continue;
        }
        CoreLog.w(
          "B站播放信息获取失败：roomId=${queryParameters["room_id"]} "
          "attempt=${attempt + 1}/${retryDelays.length + 1} error=$e",
        );
        rethrow;
      }
    }
    throw CoreError("B站播放信息接口重试失败");
  }

  Future<T> _throttlePlayInfoRequest<T>(Future<T> Function() action) {
    final task = _playInfoRequestQueue.catchError((_) {}).then((_) async {
      const minInterval = Duration(milliseconds: 450);
      final elapsed = DateTime.now().difference(_lastPlayInfoRequestAt);
      if (elapsed < minInterval) {
        await Future.delayed(minInterval - elapsed);
      }
      _lastPlayInfoRequestAt = DateTime.now();
      return action();
    });
    _playInfoRequestQueue = task.then((_) {}, onError: (_) {});
    return task;
  }

  @override
  Future<LiveCategoryResult> getRecommendRooms({int page = 1}) async {
    const baseUrl =
        "https://api.live.bilibili.com/xlive/web-interface/v1/second/getListByArea";
    var url = "$baseUrl?platform=web&sort=online&page_size=30&page=$page";

    var queryParams = await getWbiSign(url);

    var result = await HttpClient.instance.getJson(
      baseUrl,
      queryParameters: queryParams,
      header: await getHeader(),
    );

    var hasMore = (result["data"]["list"] as List).isNotEmpty;
    var items = <LiveRoomItem>[];
    for (var item in result["data"]["list"]) {
      var roomItem = LiveRoomItem(
        roomId: item["roomid"].toString(),
        title: item["title"].toString(),
        cover: "${item["cover"]}@400w.jpg",
        userName: item["uname"].toString(),
        online: int.tryParse(item["online"].toString()) ?? 0,
      );
      items.add(roomItem);
    }
    return LiveCategoryResult(hasMore: hasMore, items: items);
  }

  @override
  Future<LiveRoomDetail> getRoomDetail({required String roomId}) async {
    var roomInfo = await getRoomInfo(roomId: roomId);
    var realRoomId = roomInfo["room_info"]["room_id"].toString();

    const danmuInfoBaseUrl =
        "https://api.live.bilibili.com/xlive/web-room/v1/index/getDanmuInfo";
    var danmuInfoUrl = "$danmuInfoBaseUrl?id=$realRoomId";
    var queryParams = await getWbiSign(danmuInfoUrl);
    Map? danmuData;
    List<String> serverHosts = [];
    bool danmakuNologin = false;
    try {
      var roomDanmakuResult = await HttpClient.instance.getJson(
        danmuInfoBaseUrl,
        queryParameters: queryParams,
        header: await getHeader(),
      );

      // B站可能只拦截弹幕信息接口。此接口失败不应阻止进入直播间。
      final data = roomDanmakuResult["data"];
      if (data is Map) {
        danmuData = data;
        serverHosts = parseDanmuHosts(data);
      } else {
        CoreLog.w(
          "B站弹幕信息为空：roomId=$realRoomId code=${roomDanmakuResult["code"]} "
          "message=${roomDanmakuResult["message"]}",
        );
      }
    } catch (e) {
      CoreLog.w("B站弹幕信息获取失败：roomId=$realRoomId error=$e");
    }

    // 登录态可能被弹幕接口风控（如 -352），而未登录请求不受影响（issue #150）。
    // 回退后必须以游客身份连接弹幕：uid 置 0 且不携带登录 cookie，
    // 否则认证包 uid 与 token 所属身份不一致会被服务器强制断开。
    if (danmuData == null && cookie.isNotEmpty) {
      try {
        var roomDanmakuResult = await HttpClient.instance.getJson(
          danmuInfoBaseUrl,
          queryParameters: queryParams,
          header: await getNologinHeader(),
        );
        final data = roomDanmakuResult["data"];
        if (data is Map) {
          danmuData = data;
          serverHosts = parseDanmuHosts(data);
          danmakuNologin = true;
          CoreLog.w(
            "B站弹幕信息登录态获取失败，已回退未登录获取：roomId=$realRoomId",
          );
        } else {
          CoreLog.w(
            "B站弹幕信息未登录回退仍为空：roomId=$realRoomId "
            "code=${roomDanmakuResult["code"]} "
            "message=${roomDanmakuResult["message"]}",
          );
        }
      } catch (e) {
        CoreLog.w("B站弹幕信息未登录回退失败：roomId=$realRoomId error=$e");
      }
    }

    //var buvid = await getBuvid();
    String? liveStartTime = roomInfo["room_info"]?["live_start_time"]
        ?.toString();

    return LiveRoomDetail(
      roomId: realRoomId,
      title: roomInfo["room_info"]["title"].toString(),
      cover: roomInfo["room_info"]["cover"].toString(),
      userName: roomInfo["anchor_info"]["base_info"]["uname"].toString(),
      userAvatar: "${roomInfo["anchor_info"]["base_info"]["face"]}@100w.jpg",
      online: asT<int?>(roomInfo["room_info"]["online"]) ?? 0,
      status: (asT<int?>(roomInfo["room_info"]["live_status"]) ?? 0) == 1,
      url: "https://live.bilibili.com/$roomId",
      introduction: roomInfo["room_info"]["description"].toString(),
      notice: "",
      danmakuData: BiliBiliDanmakuArgs(
        roomId: int.tryParse(realRoomId) ?? 0,
        uid: danmakuNologin ? 0 : userId,
        token: danmuData?["token"]?.toString() ?? "",
        serverHost: serverHosts.isNotEmpty
            ? serverHosts.first
            : "broadcastlv.chat.bilibili.com",
        buvid: buvid3,
        cookie: danmakuNologin ? "" : cookie,
      ),
      showTime: liveStartTime, // 将 liveStartTime 赋值给 showTime 字段
      categoryId: roomInfo["room_info"]["area_id"]?.toString(),
      categoryName: roomInfo["room_info"]["area_name"]?.toString(),
      categoryParentId: roomInfo["room_info"]["parent_area_id"]?.toString(),
      categoryParentName: roomInfo["room_info"]["parent_area_name"]?.toString(),
    );
  }

  Future<Map<String, dynamic>> getRoomInfo({required String roomId}) async {
    var url =
        "https://api.live.bilibili.com/xlive/web-room/v1/index/getInfoByRoom?room_id=$roomId";
    var queryParams = await getWbiSign(url);
    var result = await HttpClient.instance.getJson(
      "https://api.live.bilibili.com/xlive/web-room/v1/index/getInfoByRoom",
      queryParameters: queryParams,
      header: await getHeader(),
    );
    return result["data"];
  }

  @override
  Future<LiveSearchRoomResult> searchRooms(
    String keyword, {
    int page = 1,
  }) async {
    var result = await HttpClient.instance.getJson(
      "https://api.bilibili.com/x/web-interface/search/type?context=&search_type=live&cover_type=user_cover",
      queryParameters: {
        "order": "",
        "keyword": keyword,
        "category_id": "",
        "__refresh__": "",
        "_extra": "",
        "highlight": 0,
        "single_column": 0,
        "page": page,
      },
      header: await getHeader(),
    );

    var items = <LiveRoomItem>[];
    for (var item in result["data"]["result"]["live_room"] ?? []) {
      var title = item["title"].toString();
      //移除title中的<em></em>标签
      title = title.replaceAll(RegExp(r"<.*?em.*?>"), "");
      var roomItem = LiveRoomItem(
        roomId: item["roomid"].toString(),
        title: title,
        cover: "https:${item["cover"]}@400w.jpg",
        userName: item["uname"].toString(),
        online: int.tryParse(item["online"].toString()) ?? 0,
      );
      items.add(roomItem);
    }
    return LiveSearchRoomResult(hasMore: items.length >= 40, items: items);
  }

  @override
  Future<LiveSearchAnchorResult> searchAnchors(
    String keyword, {
    int page = 1,
  }) async {
    var result = await HttpClient.instance.getJson(
      "https://api.bilibili.com/x/web-interface/search/type?context=&search_type=live_user&cover_type=user_cover",
      queryParameters: {
        "order": "",
        "keyword": keyword,
        "category_id": "",
        "__refresh__": "",
        "_extra": "",
        "highlight": 0,
        "single_column": 0,
        "page": page,
      },
      header: await getHeader(),
    );

    var items = <LiveAnchorItem>[];
    for (var item in result["data"]["result"] ?? []) {
      var uname = item["uname"].toString();
      //移除title中的<em></em>标签
      uname = uname.replaceAll(RegExp(r"<.*?em.*?>"), "");
      var anchorItem = LiveAnchorItem(
        roomId: item["roomid"].toString(),
        avatar: "https:${item["uface"]}@400w.jpg",
        userName: uname,
        liveStatus: item["is_live"],
      );
      items.add(anchorItem);
    }
    return LiveSearchAnchorResult(hasMore: items.length >= 40, items: items);
  }

  @override
  Future<bool> getLiveStatus({required String roomId}) async {
    var result = await HttpClient.instance.getJson(
      "https://api.live.bilibili.com/room/v1/Room/get_info",
      queryParameters: {"room_id": roomId},
      header: await getHeader(),
    );
    return (asT<int?>(result["data"]["live_status"]) ?? 0) == 1;
  }

  @override
  Future<List<LiveSuperChatMessage>> getSuperChatMessage({
    required String roomId,
    LiveRoomDetail? detail,
  }) async {
    var result = await HttpClient.instance.getJson(
      "https://api.live.bilibili.com/av/v1/SuperChat/getMessageList",
      queryParameters: {"room_id": roomId},
      header: await getHeader(),
    );
    List<LiveSuperChatMessage> ls = [];
    for (var item in result["data"]?["list"] ?? []) {
      var message = LiveSuperChatMessage(
        backgroundBottomColor: item["background_bottom_color"].toString(),
        backgroundColor: item["background_color"].toString(),
        endTime: DateTime.fromMillisecondsSinceEpoch(item["end_time"] * 1000),
        face: "${item["user_info"]["face"]}@200w.jpg",
        message: item["message"].toString(),
        price: item["price"],
        startTime: DateTime.fromMillisecondsSinceEpoch(
          item["start_time"] * 1000,
        ),
        userName: item["user_info"]["uname"].toString(),
      );
      ls.add(message);
    }
    return ls;
  }

  @override
  Future<List<LiveContributionRankItem>> getContributionRank({
    required String roomId,
    LiveRoomDetail? detail,
  }) async {
    final roomInfo = await getRoomInfo(roomId: roomId);
    final roomRankItems =
        (roomInfo["room_rank_info"]?["user_rank_entry"]?["user_contribution_rank_entry"]?["item"]
            as List?) ??
        const [];
    if (roomRankItems.isNotEmpty) {
      return roomRankItems.map(_mapContributionRankItem).toList();
    }

    var roomData = roomInfo["room_info"] ?? {};
    var uid = roomData["uid"]?.toString() ?? "";
    var realRoomId = roomData["room_id"]?.toString() ?? roomId;
    if (uid.isEmpty) {
      return [];
    }

    var result = await HttpClient.instance.getJson(
      "https://api.live.bilibili.com/xlive/general-interface/v1/rank/queryContributionRank",
      queryParameters: {
        "ruid": uid,
        "room_id": realRoomId,
        "page": 1,
        "page_size": 50,
      },
      header: await getHeader(),
    );
    final items = (result["data"]?["item"] as List?) ?? const [];
    return items.map(_mapContributionRankItem).toList();
  }

  LiveContributionRankItem _mapContributionRankItem(dynamic item) {
    final medalInfo = item["medal_info"] ?? item["uinfo"]?["medal"];
    final wealthLevelRaw =
        item["wealth_level"] ?? item["uinfo"]?["wealth"]?["level"];
    final wealthLevel = int.tryParse(wealthLevelRaw?.toString() ?? "");
    final guardLevel = int.tryParse(item["guard_level"].toString()) ?? 0;

    return LiveContributionRankItem(
      rank: int.tryParse(item["rank"].toString()) ?? 0,
      userName:
          item["name"]?.toString() ??
          item["uinfo"]?["base"]?["name"]?.toString() ??
          "",
      avatar:
          item["face"]?.toString() ??
          item["uinfo"]?["base"]?["face"]?.toString() ??
          "",
      scoreText: item["score"]?.toString() ?? "0",
      userLevel: wealthLevel,
      userLevelText: wealthLevel == null || wealthLevel <= 0
          ? null
          : "财富 $wealthLevel",
      fansLevel: int.tryParse(
        (medalInfo?["level"] ?? medalInfo?["medal_level"]).toString(),
      ),
      fansName:
          medalInfo?["name"]?.toString() ??
          medalInfo?["medal_name"]?.toString(),
      scoreDetail: guardLevel > 0 ? "舰队 $guardLevel" : null,
    );
  }

  /// 获取 buvid3 和 buvid4
  /// 返回buvid3和buvid4
  /// ``` json
  /// {
  ///   "b_3": "buvid3",
  ///   "b_4": "buvid4",
  /// }
  /// ```
  Future<Map> getBuvid() async {
    try {
      if (cookie.contains("buvid3")) {
        return {
          "b_3": RegExp(r"buvid3=(.*?);").firstMatch(cookie)?.group(1) ?? "",
          "b_4": RegExp(r"buvid4=(.*?);").firstMatch(cookie)?.group(1) ?? "",
        };
      }

      var result = await HttpClient.instance.getJson(
        "https://api.bilibili.com/x/frontend/finger/spi",
        queryParameters: {},
        header: {
          "user-agent": kDefaultUserAgent,
          "referer": kDefaultReferer,
          "cookie": cookie,
        },
      );
      return result["data"];
    } catch (e) {
      return {"b_3": "", "b_4": ""};
    }
  }

  static String kImgKey = '';
  static String kSubKey = '';
  static const List<int> mixinKeyEncTab = [
    46,
    47,
    18,
    2,
    53,
    8,
    23,
    32,
    15,
    50,
    10,
    31,
    58,
    3,
    45,
    35,
    27,
    43,
    5,
    49,
    33,
    9,
    42,
    19,
    29,
    28,
    14,
    39,
    12,
    38,
    41,
    13,
    37,
    48,
    7,
    16,
    24,
    55,
    40,
    61,
    26,
    17,
    0,
    1,
    60,
    51,
    30,
    4,
    22,
    25,
    54,
    21,
    56,
    59,
    6,
    63,
    57,
    62,
    11,
    36,
    20,
    34,
    44,
    52,
  ];
  Future<(String, String)> getWbiKeys() async {
    if (kImgKey.isNotEmpty && kSubKey.isNotEmpty) {
      return (kImgKey, kSubKey);
    }
    // 获取最新的 img_key 和 sub_key
    var resp = await HttpClient.instance.getJson(
      'https://api.bilibili.com/x/web-interface/nav',
      header: await getHeader(),
    );

    var imgUrl = resp["data"]["wbi_img"]["img_url"].toString();
    var subUrl = resp["data"]["wbi_img"]["sub_url"].toString();
    var imgKey = imgUrl.substring(imgUrl.lastIndexOf('/') + 1).split('.').first;
    var subKey = subUrl.substring(subUrl.lastIndexOf('/') + 1).split('.').first;

    kImgKey = imgKey;
    kSubKey = subKey;

    return (imgKey, subKey);
  }

  String getMixinKey(String origin) {
    // 对 imgKey 和 subKey 进行字符顺序打乱编码
    return mixinKeyEncTab.fold("", (s, i) => s + origin[i]).substring(0, 32);
  }

  Future<Map<String, String>> getWbiSign(String url) async {
    var (imgKey, subKey) = await getWbiKeys();

    // 为请求参数进行 wbi 签名
    var mixinKey = getMixinKey(imgKey + subKey);
    var currentTime = DateTime.now().millisecondsSinceEpoch ~/ 1000;

    var queryParams = Map<String, String>.from(Uri.parse(url).queryParameters);

    queryParams["wts"] = currentTime.toString(); // 添加 wts 字段

    //按照 key 重排参数
    Map<String, String> map = {};
    var sortedKeys = queryParams.keys.toList()..sort();
    for (var key in sortedKeys) {
      var value = queryParams[key]!;
      // 过滤 value 中的 "!'()*" 字符
      map[key] = value
          .toString()
          .split('')
          .where((c) => "!'()*".contains(c) == false)
          .join('');
    }

    var query = map.keys
        .map((key) => "$key=${Uri.encodeQueryComponent(map[key]!)}")
        .join("&");
    var wbiSign = md5.convert(utf8.encode("$query$mixinKey")).toString();
    queryParams["w_rid"] = wbiSign;
    return queryParams;
  }

  Future<String> getAccessId() async {
    if (accessId.isNotEmpty) {
      return accessId;
    }

    // 获取 access_id
    var resp = await HttpClient.instance.getText(
      "https://live.bilibili.com/lol",
      queryParameters: {},
      header: await getHeader(),
    );
    var id = RegExp(
      r'"access_id":"(.*?)"',
    ).firstMatch(resp)?.group(1)?.replaceAll("\\", "");
    accessId = id ?? "";
    return accessId;
  }
}
