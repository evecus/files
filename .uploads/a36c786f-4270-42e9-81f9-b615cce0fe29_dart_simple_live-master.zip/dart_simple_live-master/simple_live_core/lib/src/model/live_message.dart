import 'dart:convert';

enum LiveMessageType {
  /// 聊天
  chat,

  /// 礼物,暂时不支持
  gift,

  /// 在线人数
  online,

  /// 醒目留言
  superChat,
}

class LiveMessage {
  /// 消息类型
  final LiveMessageType type;

  /// 用户名
  final String userName;

  /// 信息
  final String message;

  /// 数据
  /// 单Type=Online时，Data为在线人数（抖音为当前在线，其余平台为各自在线口径）
  final dynamic data;

  /// Type=Online 时的累计观看人数（目前仅抖音弹幕提供；其余平台为 null）
  final int? totalViews;

  /// 弹幕颜色
  final LiveMessageColor color;

  /// 弹幕内表情图片地址
  final List<String>? imageUrls;

  /// 富文本消息片段。
  ///
  /// 按平台返回的顺序保存文字和图片，方便聊天区和悬浮弹幕
  /// 把表情插回原始位置。旧渲染端可继续只读 [message] 和 [imageUrls]。
  final List<LiveMessageSpan>? spans;

  LiveMessage({
    required this.type,
    required this.userName,
    required this.message,
    this.data,
    this.totalViews,
    required this.color,
    this.imageUrls,
    this.spans,
  });

  @override
  String toString() {
    return json.encode({
      "type": type.index,
      "userName": userName,
      "message": message,
      "data": data.toString(),
      "color": color.toString(),
      "imageUrls": imageUrls,
      "spans": spans?.map((e) => e.toJson()).toList(),
    });
  }
}

class LiveMessageSpan {
  final String? text;
  final String? imageUrl;

  const LiveMessageSpan.text(this.text) : imageUrl = null;
  const LiveMessageSpan.image(this.imageUrl) : text = null;

  bool get isImage => imageUrl != null && imageUrl!.trim().isNotEmpty;
  bool get isText => text != null && text!.isNotEmpty;

  Map<String, dynamic> toJson() => {"text": text, "imageUrl": imageUrl};
}

class LiveMessageColor {
  final int r, g, b;
  LiveMessageColor(this.r, this.g, this.b);
  static LiveMessageColor get white => LiveMessageColor(255, 255, 255);
  static LiveMessageColor numberToColor(int intColor) {
    var obj = intColor.toRadixString(16);

    LiveMessageColor color = LiveMessageColor.white;
    if (obj.length == 4) {
      obj = "00$obj";
    }
    if (obj.length == 6) {
      var R = int.parse(obj.substring(0, 2), radix: 16);
      var G = int.parse(obj.substring(2, 4), radix: 16);
      var B = int.parse(obj.substring(4, 6), radix: 16);

      color = LiveMessageColor(R, G, B);
    }
    if (obj.length == 8) {
      var R = int.parse(obj.substring(2, 4), radix: 16);
      var G = int.parse(obj.substring(4, 6), radix: 16);
      var B = int.parse(obj.substring(6, 8), radix: 16);
      //var A = int.parse(obj.substring(0, 2), radix: 16);
      color = LiveMessageColor(R, G, B);
    }

    return color;
  }

  @override
  String toString() {
    return "#${r.toRadixString(16).padLeft(2, '0')}${g.toRadixString(16).padLeft(2, '0')}${b.toRadixString(16).padLeft(2, '0')}";
  }
}

class LiveSuperChatMessage {
  final String? id;
  final String userName;
  final String face;
  final String message;
  final int price;
  final DateTime startTime;
  final DateTime endTime;
  final String backgroundColor;
  final String backgroundBottomColor;
  LiveSuperChatMessage({
    this.id,
    required this.backgroundBottomColor,
    required this.backgroundColor,
    required this.endTime,
    required this.face,
    required this.message,
    required this.price,
    required this.startTime,
    required this.userName,
  });

  @override
  String toString() {
    return json.encode({
      "id": id,
      "userName": userName,
      "face": face,
      "message": message,
      "price": price,
      "startTime": startTime,
      "endTime": endTime,
      "backgroundColor": backgroundColor,
      "backgroundBottomColor": backgroundBottomColor,
    });
  }
}
